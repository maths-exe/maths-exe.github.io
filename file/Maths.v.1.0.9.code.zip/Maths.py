from tkinter import *
import tkinter.ttk as ttk
import sv_ttk
from PIL import ImageTk, Image
from tkinter.font import nametofont
from time import sleep
from threading import Thread
import pywinstyles as pws
from os import listdir
from random import randint
from re import match
from configparser import ConfigParser
from tkinterweb.htmlwidgets import HtmlFrame

Config = ConfigParser()
Config.read(".settings/OptionShow.cfg")

pages = []

# 内容
def get(file):
    result = open(file=file, mode="r", encoding="utf-8").read()
    return eval(result)
def get2(file):
    result = open(file=file, mode="r", encoding="utf-8").read()
    return result

def setconfig(setname, write):
    file = open(f".settings/{setname}.set", mode="w+", encoding="utf-8")
    file.read()
    file.write(write)
    file.close()
def setget(setname, mode=2):
    result = open(file=f".settings/{setname}.set", mode="r", encoding="utf-8").read()
    if mode == 1:
        return eval(result)
    elif mode == 2:
        return int(result)
    elif mode == 3:
        return result
def font(size):
    return ("黑体", size)

# 读取文件
style = get(".style/light.style")
# 定义
allfilenum = get2(".include/AllFileNumber.set")
file = [".include/algebra/", ".include/calculus/", ".include/data/", ".include/geometry/", ".include/physics/", ".include/numbers/"]
search_file = []
search = []

lang = get(".settings/langauge/zh_CN.lang")

MainWidth = 700

width  = 200
width1 = 0
width2 = 0
width3 = 200

width4 = 200
width5 = 0
width6 = 200

# class
class lButton(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)

    def binding(self, function):
        def leave(event):
            self["background"] = style["lButton"]["Before"]["TextBack"]
            self["foreground"] = style["lButton"]["Before"]["TextFore"]
            self.config(highlightthickness=0)
        def enter(event):
            self["background"] = style["lButton"]["Pass"]["TextBack"]
            self.config(highlightthickness=1, highlightbackground=style["lButton"]["HighLightBack"])

        self.bind("<Leave>", leave)
        self.bind("<Enter>", enter)
        self.bind("<Button-1>", function)
    def acter(self):
        self["background"] = style["lButton"]["After"]["TextBack"]
class LightLabel(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)
    def light(self):
        self.red   = 255
        self.green = 255
        self.blue  = 255
        def color():
            self.config(fg=f"#{hex(self.red)[2:]+hex(self.green)[2:]+hex(self.blue)[2:]}")
            self.red   -= 1
            self.green -= 1
            self.blue  -= 1
            if self.red <= 0:
                return color2()
            elif len(hex(self.red)[2:]) == 1:
                self.config(fg=f"#0{hex(self.red)[2:]}0{hex(self.green)[2:]}0{hex(self.blue)[2:]}")
            self.master.after(2, color)        
        def color2():
            self.config(fg=f"#0{hex(self.red)[2:]}0{hex(self.green)[2:]}0{hex(self.blue)[2:]}")
            self.red   += 1
            self.green += 1
            self.blue  += 1
            if self.red >= 255:
                return color()
            elif len(hex(self.red)[2:]) == 2:
                self.config(fg=f"#{hex(self.red)[2:]+hex(self.green)[2:]+hex(self.blue)[2:]}")
            self.master.after(2, color2)
        color()
class LButton(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)
    def binding(self, func):
        self.config(highlightthickness=1, highlightbackground=style["CanvasW"]["HighLightBack2"])
        def leave(event):
            self.config(highlightbackground=style["CanvasW"]["HighLightBack2"])
        def enter(event):
            self.config(highlightbackground=style["CanvasW"]["HighLightBack"])
        self.bind("<Leave>", leave)
        self.bind("<Enter>", enter)
        try:
            self.bind("<Button-1>", func)
        except:
            pass
    def unbinding(self):
        self.unbind("<Leave>")
        self.unbind("<Enter>")
        try:
            self.unbind("<Button-1>")
        except:
            pass

class Choose:
    def __init__(self, true:LButton, false:tuple):
        self.true = true
        self.false = false
        def true_anwser(event):
            self.true.config(highlightbackground="#2ee62e")
            self.true.unbinding()
            for i in self.false:
                i.unbinding()
        def false_answer1(event):
            self.true.config(highlightbackground="#2ee62e")
            self.false[0].config(highlightbackground="#e62100")
            self.true.unbinding()
            for i in self.false:
                i.unbinding()
        def false_answer2(event):
            self.true.config(highlightbackground="#2ee62e")
            self.false[1].config(highlightbackground="#e62100")
            self.true.unbinding()
            for i in self.false:
                i.unbinding()
        def false_answer3(event):
            self.true.config(highlightbackground="#2ee62e")
            self.false[2].config(highlightbackground="#e62100")
            self.true.unbinding()
            for i in self.false:
                i.unbinding()
        
        self.true.binding(true_anwser)
        i = 0
        for w in self.false:
            i += 1
            exec(f"w.binding(false_answer{i})")

class Lutton(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)
    def binding(self, function):
        self.config(highlightthickness=1, highlightbackground=style["CanvasW"]["HighLightBack2"])
        def leave(event):
            self.config(highlightbackground=style["CanvasW"]["HighLightBack2"])
        def enter(event):
            self.config(highlightbackground=style["CanvasW"]["HighLightBack"])
        self.bind("<Leave>", leave)
        self.bind("<Enter>", enter)
        try:
            self.bind("<Button-1>", function)
        except:
            pass
class lon(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)
    def binding(self, type):
        if type == 1:
        #self.config(highlightthickness=1, highlightbackground=style["CanvasW"]["HighLightBack2"])
            def leave(event):
                self.config(bg=style["CanvasW"]["Background1"])
            def enter(event):
                self.config(bg=style["CanvasW"]["Background2"])
        elif type == 2:
            def leave(event):
                self.config(fg=style["CanvasW"]["TextFore3"])
            def enter(event):
                self.config(fg=style["CanvasW"]["TextFore4"])

        self.bind("<Leave>", leave)
        self.bind("<Enter>", enter)

class FrameRead(Text):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'text', cnf, kw)
    def binding(self):
        self["relief"] = FLAT
        self["cursor"] = 'arrow'
        def disable_text_selection(event):
            return "break"
        self.bind("<Button-1>", disable_text_selection)
    def read(self, file):
        exec('\n'.join(open(file=file, mode="r", encoding="utf-8").read().split("\n")[0:]))
    def clear(self):
        self.delete(1.0, END)

class conputlib:
   def __init__(self, master,  c0:tuple, c1:tuple, step, wait_time=0, col="bg"):
      self.master= master
      self.N = -1
      self.c0 = c0
      self.c1 = c1
      self.RGB = self.R = self.G = self.B = self.color = None
      self.step = step

      def _func():
         self.N += 1
         self.RGB = (
            self.c0[0]+(self.c1[0]-self.c0[0]) * self.N / self.step,
            self.c0[1]+(self.c1[1]-self.c0[1]) * self.N / self.step,
            self.c0[2]+(self.c1[2]-self.c0[2]) * self.N / self.step
         )
         self.R = hex(int(self.RGB[0])).replace("0x", "")
         self.G = hex(int(self.RGB[1])).replace("0x", "")
         self.B = hex(int(self.RGB[2])).replace("0x", "")
         if len(self.R) == 1:
            self.R = "0" + self.R
         if len(self.G) == 1:
            self.G = "0" + self.G
         if len(self.B) == 1:
            self.B = "0" + self.B

         self.master[col] = f"#{self.R}{self.G}{self.B}"

         if self.N == self.step:
            return 0
         
         w.after(10, _func)
      w.after(wait_time, _func)
   def temp(self, func, sleepn=0):
       def app():
           w.after(sleepn)
           while 1:
               if self.N == self.step:
                    func()
                    return "break"
               else:
                   sleep(0.001)
    
       self.th = Thread(target=app, daemon=True)
       self.th.start()
            

class latter:
    def __init__(self, matser, text):
        self.text = text
        self.master = matser
        self.word = ''

        def __():
            for i in self.text:
                self.word += i
                self.master["text"] = self.word
                sleep(0.1)
            return "break"

        self.th = Thread(target=__, daemon=True)
        self.th.start()

class ScrollbarFrame(Canvas):
    def __init__(self, master=None, **kw):
        self.frame = Frame(master)
        self.vbar = Scrollbar(self.frame)
        self.vbar.pack(side=RIGHT, fill=Y)

        kw.update({'yscrollcommand': self.vbar.set})

        Canvas.__init__(self, self.frame, **kw)
        self.pack(side=LEFT, fill=BOTH, expand=True)
        self.vbar['command'] = self.yview

        def myfunction(event):
            self.configure(scrollregion=self.bbox("all"), highlightthickness=0, relief=FLAT, bd=0)
        self.frame2 = Frame(self, highlightthickness=0, relief=FLAT)
        self.__important__ = self.create_window((0,0), window=self.frame2, anchor=N, width=700)
        
        global wheel

        def wheel(event):
            if self.vbar.get() == (0.0, 1.0):
                pass
            else:
                self.yview_scroll(-1*(int(event.delta/120)), "units")

        self.frame2.bind("<MouseWheel>", wheel)
        self.bind("<MouseWheel>", wheel)
        self.frame2.bind("<Configure>", myfunction)

        text_meths = vars(Canvas).keys()
        methods = vars(Pack).keys() | vars(Grid).keys() | vars(Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

    def do(self, type=2):
        def loop():
            while 1:
                try:
                    if type == 1:
                        width = int(self.canvasx(self.winfo_width()/2))
                        self.coords(self.__important__, width, 0)
                    elif type == 2:
                        width = self.winfo_width()
                        self.itemconfig(self.__important__, width=width)
                    sleep(0.00001)
                except:
                    break
        self.th = Thread(target=loop, daemon=True)
        self.th.start()

    def read(self, filepath):
       file = open(file=filepath, mode="r", encoding="utf-8")
       exec(file.read())
       file.close()

    def binding(self, color):
        self.frame2['bg'] = color
        
def run(file2):
    file = open(file=file2, mode="r", encoding="utf-8")
    exec(file.read())
    file.close()
    return 0

class loading:
    def __init__(self, master:Label, func="un", value=200):
        self.master = master
        self.sec    = 0
        self.value  = value
        self.master.place_configure(x=-int(self.value/2))
        self.func   = func

        def loop():
            for i in range(-100, self.value):
                self.master.place_configure(width=i)
                if i >= 120:
                    self.sec += 0.0005
                    sleep(self.sec)
                sleep(0.01)
            if self.func == "un":
                return "break"
            else:
                self.func()
            

        self.th = Thread(target=loop, daemon=True)
        self.th.start()

# 主体
def main():
    global w, C_1
    w = Tk()
    # 设置
    w.title("Maths")

    w.config(background=style["TextBack"])
    w.geometry(f"{setget('WindowSize', 3)}")
    # 图标
    w.iconbitmap(".image/icon/images64.ico")
    w.wm_iconbitmap(".image/icon/images64.ico")
    w.wm_minsize(width=768, height=475)
    # 全局字体

    default_font2 = nametofont("TkDefaultFont")
    default_font2.configure(family="黑体", size=10)
    # 菜单
    MainUI = Frame(w, bg=style["ChooseUI"], width=200)
        #MainUI['bg']='red'
    MainUI.place(anchor=NW, x=0, y=0, relheight=1)
    # 显示
    MathIsFun = Label(MainUI, bg=style["ChooseUI"], fg=style["TextFore2"], text="Maths", font=("宋体", 18))
    MathIsFun.place(anchor=NW, x=10, y=10)
        #Label(w, bg=style["TextBack"], fg=style["TextFore3"], text="Mathematics", font=("黑体", 10)).place(anchor="se", relx=1, rely=1, y=-10, x=-10)
    
    iconimage1 = ImageTk.PhotoImage(Image.open(".image/icon/C-1.ms"))
    iconimage2 = ImageTk.PhotoImage(Image.open(".image/icon/C-2.ms"))
    C_1 = Label(MainUI, bg="#198cc1", fg="#ffffff", image=iconimage1, width=14, height=14)
    C_1["image"] = iconimage1
    def enter(event):
        C_1["image"] = iconimage1
    def leave(event):
        C_1["image"] = iconimage2
    C_1.bind("<Leave>", enter)
    C_1.bind("<Enter>", leave)
    
    # 搜索框函数
    def no_button(event):
        search.insert(INSERT, lang["10001"]+lang["00001"])
        search.icursor(0)
        search["fg"] = style["SearchW"]["Text"]
    search = Entry(MainUI, relief=FLAT, highlightthickness=1, highlightbackground=style["SearchW"]["Before"], insertwidth=1)
    search.place(anchor='center', x=100, y=60, width=190)
    no_button(1)
    search.config(state="disabled")
    text1 = FrameRead(w, bg=style["TextBack"], font="黑体")
    text1.place(anchor=NE, relx=1, relheight=1, relwidth=1, width=-202)
    text1.binding()

    # 函数
    global useless
    def useless(event):
        pass
    def close(event):
        if Config.get("Startup", "Size") == "2":
            setconfig(f"WindowSize", f"{w.winfo_width()}x{w.winfo_height()}")
        Z.acter()
        w.destroy()
    def settings(event):
        global Set_x
        Set_x = 30
        A.acter()
        Set = Frame(w, bg=style["Settings"]["Background"])
        Set.place(relheight=1, relwidth=1, y=30, anchor=NW)
        def do():
            global Set_x
            Set_x -= 1
            if Set_x == -1:
                Set_x = 0
                return 0
            Set.place_configure(y=Set_x)
            w.after(1, do)
        w.after(50, do)
        def do2():
            global Set_x
            Set_x += 1
            if Set_x == 31:
                Set_x = 30
                return Set.destroy()
            Set.place_configure(y=Set_x)
            w.after(1, do2)

        settingsnum = []
        def exite(event):
            w.after(50, do2)
        def loade(event):
            configset = open(file=".settings/OptionShow.cfg", mode="w")
            Config.write(configset)

        SetUI = ScrollbarFrame(Set, bg=style["Settings"]["Background"])
        SetUI.binding(style["Settings"]["Background"])
        SetUI.do()
        SetUI.place(relheight=1, relwidth=1, height=-50)

        line = Label(Set, bg='#565656').place(rely=1, y=-50, height=1, relwidth=1)

        loadk = lButton(Set, text="保存", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        loadk.place(anchor="center", relx=1, rely=1, y=-25, x=-130, width=60)
        loadk.binding(loade)
        exitk = LButton(Set, text="退出")
        exitk.place(anchor="center", relx=1, rely=1, y=-25, x=-60, width=60)
        exitk.binding(exite)

        class SetFrame(LabelFrame):
            def __init__(self, master=None, cnf={}, **kw):
                Widget.__init__(self, master, 'labelframe', cnf, kw)
                self.pack(fill=BOTH, padx=20, pady=2)
            def show(self, text1, text2):
                Label(self, text=text1, bg=style["Settings"]["Background"], fg=style["Settings"]["Foreground"]).grid(sticky="nw")
                Label(self, text=text2, bg=style["Settings"]["Background"], fg=style["Settings"]["Foreground2"], font=("黑体", 9)).grid(sticky="nw")
        
        Label(SetUI.frame2, text="启动", bg=style["Settings"]["Background"], fg=style["Settings"]["Foreground"], font=("黑体", 20, "bold")).pack(anchor=NW, padx=10, pady=5)

        _01 = SetFrame(SetUI.frame2, bg="#ffffff", highlightthickness=1, highlightbackground="#ddd", relief=FLAT)
        _01.show("启动大小", "启动时窗口的大小。")
        
        _01slist = ("默认", "自定义", "不设置")
        combox1 = ttk.Combobox(_01, values=_01slist)
        combox1.place(anchor="e", rely=0.5, relx=1, x=-5)
        print(_01slist[int(Config.get("Startup", "Size"))], Config.get("Startup", "Size"))
        combox1.insert(INSERT, _01slist[int(Config.get("Startup", "Size"))])

        def option_selected(event):
            selected_option = combox1.get()
            if settingsnum.count("0.0") != 0:
                del settingsnum[settingsnum.index("0.0")]
            elif settingsnum.count("0.1") != 0:
                del settingsnum[settingsnum.index("0.1")]
            elif settingsnum.count("0.2") != 0:
                del settingsnum[settingsnum.index("0.2")]
                
            if selected_option == "默认":
                Config.set("Startup", "Size", "0")
                settingsnum.append("0.0")
            elif selected_option == "自定义":
                Config.set("Startup", "Size", "1")
                settingsnum.append("0.1")
            elif selected_option == "不设置":
                Config.set("Startup", "Size", "2")
                settingsnum.append("0.2")    

        combox1["state"] = 'readonly'
        combox1.bind("<<ComboboxSelected>>", option_selected)

        _02 = SetFrame(SetUI.frame2, bg="#ffffff", highlightthickness=1, highlightbackground="#ddd", relief=FLAT)
        _02.show("启动位置", "启动时窗口的右上角的位置。")
        _03 = SetFrame(SetUI.frame2, bg="#ffffff", highlightthickness=1, highlightbackground="#ddd", relief=FLAT)
        _03.show("语言(需重新启动)", "选择应用程序的显示语言。")



    def about(event):
        B.acter()
        global width2
        AboutCUI = Frame(w, bg=style["ChooseUI"])
        AboutCUI.place(relheight=1, height=-80, y=80, anchor=NW)
        def MathCUIplus3():
            global width2
            width2 += 2#plus
            AboutCUI.place_configure(width=width2)
            if width2 >= 200:
                ChooseUI.place_forget()
                Back3.place(anchor="s", x=100, rely=1, y=-10, width=160.0, height=30)
                return 0
            w.after(1, MathCUIplus3)
        MathCUIplus3()
        def back3(event):
            Back3.acter()
            text1.clear()
            ChooseUI.place(relheight=1, height=-80, y=80, anchor=NW, width=width)
            def MathCUIadd3():
                global width2
                width2 -= 2#add
                AboutCUI.place_configure(width=width2)
                if width2 <= 0:
                    AboutCUI.destroy()
                    return 0
                w.after(1, MathCUIadd3)
            MathCUIadd3()
        text1.read(".include/about/about1.frame")
        Back3 = lButton(AboutCUI, text=lang["10002"], compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Back3.binding(back3)
        
    def math1(event):
        C.acter()
        global width1
        MathCUI = Frame(w, bg=style["ChooseUI"])
        MathCUI.place(relheight=1, height=-80, y=80, anchor=NW)
        def MathCUIplus1():
            global width1
            width1 += 2#plus
            MathCUI.place_configure(width=width1)
            if width1 >= 200:
                ChooseUI.place_forget()
                Algebra.place(anchor="n", x=100, y=0, width=160.0, height=30)
                Calculus.place(anchor="n", x=100, y=30, width=160.0, height=30)
                Data.place(anchor="n", x=100, y=60, width=160.0, height=30)
                Geometry.place(anchor="n", x=100, y=90, width=160.0, height=30)
                Physics.place(anchor="n", x=100, y=120, width=160.0, height=30)
                Numbers.place(anchor="n", x=100, y=150, width=160.0, height=30)
                Back.place(anchor="s", x=100, rely=1, y=-10, width=160.0, height=30)
                return 0
            w.after(1, MathCUIplus1)
        MathCUIplus1()
        def back(event):
            Back.acter()
            Algebra.place_forget()
            Calculus.place_forget()
            Data.place_forget()
            Geometry.place_forget()
            Physics.place_forget()
            Numbers.place_forget()
            ChooseUI.place(relheight=1, height=-80, y=80, anchor=NW, width=width)
            def MathCUIadd1():
                global width1
                width1 -= 2#add
                MathCUI.place_configure(width=width1)
                if width1 <= 0:
                    MathCUI.destroy()
                    return 0
                w.after(1, MathCUIadd1)
            MathCUIadd1()
        def math2(event):
            global width3, c_1button_1_1, Algebra_sf
            Algebra.acter()
            width3 = 200
            Algebra.place_forget()
            Calculus.place_forget()
            Data.place_forget()
            Geometry.place_forget()
            Physics.place_forget()
            Numbers.place_forget()
            search.place_forget()
            MathIsFun.place_forget()
            MathCUI.place_configure(width=1)
            text1.place_forget()
            def c_1button_1_1(event):
                search.place(anchor='center', x=100, y=60, width=190)
                MathIsFun.place(anchor=NW, x=10, y=10)
                Algebra_sf.frame.destroy()
                C_1.unbind("<Button>")
                C_1.place_forget()
                def Algebra_SFadd1():
                    global width3
                    width3 += 2#add
                    MainUI.place_configure(width=width3)
                    if width3 >= 200:
                        MathCUI.place_configure(width=200)
                        Algebra.place(anchor="n", x=100, y=0, width=160.0, height=30)
                        Calculus.place(anchor="n", x=100, y=30, width=160.0, height=30)
                        Data.place(anchor="n", x=100, y=60, width=160.0, height=30)
                        Geometry.place(anchor="n", x=100, y=90, width=160.0, height=30)
                        Physics.place(anchor="n", x=100, y=120, width=160.0, height=30)
                        Numbers.place(anchor="n", x=100, y=150, width=160.0, height=30)
                        text1.place(anchor=NE, relx=1, relheight=1, relwidth=1, width=-202)
                        return 0
                    w.after(1, Algebra_SFadd1)
                Algebra_SFadd1()
            def Algebra_SFplus1():
                global width3
                width3 -= 2#add
                MainUI.place_configure(width=width3)
                if width3 <= 40:
                    C_1.place(anchor=S, x=20, rely=1, y=-10)
                    C_1.bind("<Button-1>", c_1button_1_1)
                    Algebra_sf.place(anchor=NW, relheight=1 ,relwidth=1, width=-40, x=40)
                    return 0
                w.after(1, Algebra_SFplus1)
            Algebra_SFplus1()
            # 组件
            Algebra_sf = ScrollbarFrame(w, bg=style["CanvasW"]["Background"])
            Algebra_sf.binding(style["CanvasW"]["Background"])
            Algebra_sf.do()
            Label(Algebra_sf.frame2, text="\n\n代数", fg=style["ChooseUI"], bg=style["CanvasW"]["Background"], font=("黑体", 25)).pack()
            Label(Algebra_sf.frame2, text="代数非常有趣 - 可以解决难题!\n\n", fg=style["CanvasW"]["TextFore7"], bg=style["CanvasW"]["Background"]).pack()
            Label(Algebra_sf.frame2, text="""在电脑游戏中, 你可以通过奔跑, 跳跃和寻找神秘东西来玩. 

在代数中, 你可以玩字母, 数字和符号, 还可以找到其它神秘的东西!

当你学会了一些 "技巧" 时, 弄清楚如何利用你的技能来解决每个问题就变成了一个有趣的挑战. """, justify='left', fg=style["CanvasW"]["TextFore"], bg=style["CanvasW"]["Background"]).pack()
            Label(Algebra_sf.frame2, text="\n\n\n基础知识\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)
            global Cooler
            class Cooler:
                def __init__(self, a:LButton, file):
                    self.a = a
                    self.file = file
                    def SF(event):
                        global sf, later_a
                        def later_a(event):
                            C_1.bind("<Button-1>", c_1button_1_1)
                            Algebra_sf.frame.place(anchor=NW, relheight=1 ,relwidth=1, width=-40, x=40)
                            sf.frame.destroy()
                        Algebra_sf.frame.place_forget()
                        sf = ScrollbarFrame(w, bg=style["CanvasW"]["Background"])
                        sf.binding(style["CanvasW"]["Background"])
                        sf.do(type=1)
                        sf.place(anchor=NW, relheight=1 ,relwidth=1, width=-40, x=40)
                        sf.read(self.file)
                        C_1.bind("<Button-1>", later_a)
                    self.a.binding(func=SF)
            
            run(".include/algebra.ui")

        def math3(event):
            global width4, c_1button_1_2
            Calculus.acter()
            width4 = 200
            Algebra.place_forget()
            Calculus.place_forget()
            Data.place_forget()
            Geometry.place_forget()
            Physics.place_forget()
            Numbers.place_forget()
            search.place_forget()
            MathIsFun.place_forget()
            MathCUI.place_configure(width=1)
            text1.place_forget()
            def c_1button_1_2(event):
                search.place(anchor='center', x=100, y=60, width=190)
                MathIsFun.place(anchor=NW, x=10, y=10)
                Calculus_sf.frame.destroy()
                C_1.unbind("<Button>")
                C_1.place_forget()
                def Calculus_SFadd1():
                    global width4
                    width4 += 2#add
                    MainUI.place_configure(width=width4)
                    if width4 >= 200:
                        MathCUI.place_configure(width=200)
                        Algebra.place(anchor="n", x=100, y=0, width=160.0, height=30)
                        Calculus.place(anchor="n", x=100, y=30, width=160.0, height=30)
                        Data.place(anchor="n", x=100, y=60, width=160.0, height=30)
                        Geometry.place(anchor="n", x=100, y=90, width=160.0, height=30)
                        Physics.place(anchor="n", x=100, y=120, width=160.0, height=30)
                        Numbers.place(anchor="n", x=100, y=150, width=160.0, height=30)
                        text1.place(anchor=NE, relx=1, relheight=1, relwidth=1, width=-202)
                        return 0
                    w.after(1, Calculus_SFadd1)
                Calculus_SFadd1()
            def Calculus_SFplus1():
                global width4
                width4 -= 2#add
                MainUI.place_configure(width=width4)
                if width4 <= 40:
                    C_1.place(anchor=S, x=20, rely=1, y=-10)
                    C_1.bind("<Button-1>", c_1button_1_2)
                    Calculus_sf.place(anchor=NW, relheight=1 ,relwidth=1, width=-40, x=40)
                    return 0
                w.after(1, Calculus_SFplus1)
            Calculus_SFplus1()
            
            Calculus_sf = ScrollbarFrame(w, bg=style["CanvasW"]["Background"])
            Calculus_sf.binding(style["CanvasW"]["Background"]) 
            Calculus_sf.do()
            
            Label(Calculus_sf.frame2, text="Calculus:", fg=style["ChooseUI"], bg=style["CanvasW"]["Background"], font=("黑体", 20)).pack(anchor=NW, side='top')
            Label(Calculus_sf.frame2, text="极限:", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore"], font=("黑体", 13)).pack(anchor=NW, padx=20)
            padx = 50
            b1 = LButton(Calculus_sf.frame2, text="极限简介", bg=style["CanvasW"]["Background"])
            b1.pack(anchor=NW, padx=padx)
            b1.binding(sf=Calculus_sf, func=c_1button_1_2, type=0, file=".include/calculus/calculus2.frame2")
            b2 = LButton(Calculus_sf.frame2, text="极限和无限", bg=style["CanvasW"]["Background"])
            b2.pack(anchor=NW, padx=padx)
            b2.binding(sf=Calculus_sf, func=c_1button_1_2)

        Algebra = lButton(MathCUI, text=" 代数 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Algebra.binding(math2)
        Calculus = lButton(MathCUI, text=" 微积分 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Calculus.binding(math3)
        Data = lButton(MathCUI, text=" 数据 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Data.binding(useless)
        Geometry = lButton(MathCUI, text=" 几何 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Geometry.binding(useless)
        Physics = lButton(MathCUI, text=" 物理 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Physics.binding(useless)
        Numbers = lButton(MathCUI, text=" 数字 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Numbers.binding(useless)
        
        Back = lButton(MathCUI, text=lang["10002"], compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Back.binding(back)
        
    def always_2025(event):
        D.acter()
        D.unbind("<Button-1>")
        Today = Toplevel()
        Today['bg'] = style["ChooseUI"]
        Today.geometry("490x250")
        Today.resizable(False, False)
        Today.iconbitmap(".image/icon/images64.ico")
        Today.wm_iconbitmap(".image/icon/images64.ico")
        tText1 = FrameRead(Today, bg=style["ChooseUI"], fg=style["TextFore2"], font=("黑体", 13))
        tText1.place(relheight=0.7, relwidth=0.7, anchor=CENTER, relx=0.5, rely=0.5)
        tText1.binding()
        text1 = """今年是不同的:

    |(20+25)²                 = 2025
    |(1+2+3+4+5+6+7+8+9)²     = 2025
    |1³+2³+3³+4³+5³+6³+7³+8³+9³ = 2025
        """
        tText1.insert(INSERT, text1)
        tText1.tag_add("tag_body_1", 1.0, 1.19)
        tText1.tag_config("tag_body_1", font=("CENSCBK", 17, "bold"))
        def _():
            D.bind("<Button-1>", always_2025)
            Today.destroy()
        Today.wm_protocol("WM_DELETE_WINDOW", _)
    ChooseUI = Frame(w, bg=style["ChooseUI"])
    ChooseUI.place(relheight=1, height=-80, y=80, anchor=NW, width=width)
    A = lButton(ChooseUI, text=" 设置 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    A.binding(settings)
    A.place(anchor="n", x=100, y=0, width=160.0, height=30)
    B = lButton(ChooseUI, text=" 关于 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    B.binding(about)
    B.place(anchor="n", x=100, y=30, width=160.0, height=30)
    C = lButton(ChooseUI, text=lang["10004"], compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    C.binding(math1)
    C.place(anchor="n", x=100, y=60, width=160.0, height=30)
    D = lButton(ChooseUI, text=" 2025 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    D.binding(always_2025)
    D.place(anchor="n", x=100, y=90, width=160.0, height=30)
    Z = lButton(ChooseUI, text=lang["10003"], compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    Z.binding(close)
    Z.place(anchor="s", x=100, rely=1, y=-10, width=160.0, height=30)
    def _():
        if Config.get("Startup", "Size") == "2":
            setconfig(f"WindowSize", f"{w.winfo_width()}x{w.winfo_height()}")
        w.destroy()
    w.wm_protocol("WM_DELETE_WINDOW", _)

    bg = Frame(w, bg="#ffffff")
    bg.place(anchor=NW, relheight=1, relwidth=1)
    loading1 = Label(bg, bg="#1c7ba7")
    loading1.place(anchor="w", relx=0.5, rely=0.5, y=44, x=-50, height=4, width=0)
    _img = Label(bg, text="M", bg="#1c7ba7", fg="#ffffff", font=("Century", 30))
    _img.place(anchor=CENTER, relx=0.5, rely=0.5, width=64, height=64, y=-20)
    def e():
        def e_a():
            s = 0
            r = 0
            while 1:
                s -= 32
                r -= 25
                bg.place_configure(width=s, height=r)

                print(-w.winfo_width())
                if s <= -w.winfo_width():
                    bg.destroy()
                    print(True)
                    return "break"

                sleep(0.001)
        th = Thread(target=e_a, daemon=True)
        th.start()

    def d():
        _img.destroy()
        loading1.destroy()
        a = conputlib(bg, (28,123,167), (25, 140, 193), 50, wait_time=1000)
        a.temp(e)
    def b():
        a = conputlib(_img, (255, 255, 255), (28,123,167), 50, wait_time=1000, col="fg")
        a.temp(d)
        conputlib(loading1, (255, 255, 255), (28,123,167), 50, wait_time=1000)
    def c():
        a = conputlib(bg, (255, 255, 255), (28,123,167), 50, wait_time=1000)
        conputlib(loading1, (28,123,167), (255, 255, 255), 50, wait_time=1000)
        a.temp(b)

    loading(loading1, func=c)

    w.mainloop()
# 执行
if __name__ == "__main__":
    main()
