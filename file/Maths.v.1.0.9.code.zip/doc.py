import tkinter as tk
from tkinter.ttk import *
import sv_ttk
from threading import Thread
from PIL import ImageTk, Image
from time import sleep
from math import sin, pi
from webbrowser import open as link_open

slc = eval(open(".style/default_doc.sl", "r", encoding="utf-8").read())
string = ""
version = open("version.set", "r", encoding="utf-8").read().split("\n")

class ChooseLabel:
    def __init__(self, master, text: tuple, func: tuple, y=0, frame_background="#ffffff", frame_anchor=tk.NW, cBefore="#000000", cAfter="#f3f3f3", frame_width=200, cClick_bg="#5a5a5a", foreground="#000000", cClick_fg="#eaeaea", line_color="#005a9e", line_width=2):
        """
        初始化 ChooseLabel 类

        参数:
        master (Widget): 父容器
        text (tuple): 按钮文本的元组
        func (tuple): 按钮点击事件的元组
        y (int): Frame 的 y 坐标
        frame_background (str): Frame 的背景颜色
        frame_anchor (str): Frame 的锚点
        cBefore (str): 按钮默认背景颜色
        cAfter (str): 鼠标悬停时按钮的背景颜色
        frame_width (int): Frame 的宽度
        cClick_bg (str): 按钮点击时的背景颜色
        foreground (str): 按钮的前景颜色
        cClick_fg (str): 按钮点击时的前景颜色
        line_color (str): 线条的颜色
        line_width (int): 线条的宽度
        """
        self.frame = tk.Frame(master=master, background=frame_background)
        self.frame.place(y=y, anchor=frame_anchor, width=frame_width, height=len(text) * 34)
    
        # 确保 func 是一个元组
        if not isinstance(func, tuple):
            func = (func,)
        
        # 如果 func 的长度不等于 text 的长度，填充 None
        if len(func) != len(text):
            func += (None,) * (len(text) - len(func))
        
        self.func = func

        self.buttons = []
        self.current_button = None  # 用于跟踪当前被按下的按钮
        for i in range(len(text)):
            button = Label(self.frame, text=f"   {text[i]} ", justify="left", font=("微软雅黑", 10), background=cBefore, foreground=foreground)
            button.place(anchor=tk.NW, x=5, y=i * 34, width=190, height=30)
            button.bind("<Enter>", lambda event, btn=button: btn.config(background=cAfter, foreground=foreground))
            button.bind("<Leave>", lambda event, btn=button: btn.config(background=cBefore if btn != self.current_button else cClick_bg, foreground=foreground))
            button.bind("<Button-1>", lambda event, btn=button, idx=i: self.on_button_click(btn, idx, cClick_fg, cClick_bg, foreground, cBefore))
            self.buttons.append(button)
        
        self.line = Label(self.frame, background=line_color)
        self.line.place(height=15, width=line_width, anchor=tk.E, y=15, x=6)

        # 默认点击第一个按钮
        if self.buttons:
            self.on_button_click(self.buttons[0], 0, cClick_fg, cClick_bg, foreground, cBefore)

    def on_button_click(self, button, index, cClick_fg, cClick_bg, foreground, cBefore):
        """
        按钮点击事件处理

        参数:
        button (Widget): 被点击的按钮
        index (int): 按钮的索引
        cClick_fg (str): 按钮点击时的前景颜色
        cClick_bg (str): 按钮点击时的背景颜色
        foreground (str): 按钮的前景颜色
        cBefore (str): 按钮默认背景颜色
        """
        if self.current_button:
            self.current_button.config(background=cBefore, foreground=foreground)
        button.config(background=cClick_bg, foreground=cClick_fg)
        self.current_button = button
        self.animate_line(index * 34 + 15)
        
        if callable(self.func[index]):
            self.func[index]()

    def animate_line(self, target_y):
        """
        动画移动线条到目标位置

        参数:
        target_y (int): 目标 y 坐标
        """
        def move():
            current_y = self.line.winfo_y()
            step = (target_y - current_y) / 10  # 缓冲效果

            while abs(target_y - current_y) > 1:
                current_y += step
                self.line.place(y=current_y)
                sleep(0.01)

            self.line.place(y=target_y)
            return "break"

        self.th = Thread(target=move, daemon=True).start()

class moveD:
    def __init__(self, master:Entry, y, add_no_wait=89):
        self.master = master
        self.sec = 0
        self.y = y
        var = self.y-(self.y-y*sin(add_no_wait*pi/180))

        def fluent_change():
            while 1:
                var2 = self.y-(self.y-y*sin(self.sec*pi/180))
                self.master.place(y=var2)
                if self.sec<add_no_wait:
                    sleep(0.01)
                    self.sec += 1
                if var2 == var:
                    break
            return "break"
        self.th = Thread(target=fluent_change, daemon=True)
        self.th.start()

def main():
    md = tk.Tk()
    
    md.geometry("768x475")
    md.wm_minsize(width=768, height=475)
    md.title(version[2])
    md.iconbitmap(".image/icon/image64.ico")
    md.wm_iconbitmap(".image/icon/image64.ico")
    md.config(background=slc["background"]["window-background"])
    
    global ST, line, find_entry, string
    line = ImageTk.PhotoImage(Image.open(".docTex/source/line.dtf"))
    
    Label(md, background=slc["background"]["label-background"]).place(x=200, width=20, relheight=1)
    Label(md, background=slc["background"]["label-background"]).place(anchor="ne", relx=1, width=20, relheight=1)
    Label(md, background=slc["line1-color"]).place(x=200, width=1, relheight=1)
    scrollbor = Scrollbar(md)
    scrollbor.place(anchor=tk.NE, relx=1, relheight=1, x=5)
    ST = tk.Text(md, background=slc["background"]["text-background"], borderwidth=0, fg=slc["foreground"]["text-foreground"], relief=tk.FLAT, cursor="arrow", font=("微软雅黑", 12), undo=False, takefocus=False,
                   insertwidth=1, selectbackground=slc["background"]["select-background"], selectforeground=slc["foreground"]["select-foreground"], yscrollcommand=scrollbor.set,
                      )
    ST.place(relwidth=1, relheight=1, width=-240, x=220)
    ST.bind("<Button-1>", lambda f:"break")
    scrollbor["command"] = ST.yview

    # 绑定链接点击事件
    ST.tag_bind("link", "<Button-1>", lambda event: open_link(event))
    ST.tag_bind("link", "<Enter>", lambda event: (ST.config(cursor="hand2")))
    ST.tag_bind("link", "<Leave>", lambda event: (ST.config(cursor="arrow")))

    ST.tag_config("h1", font=("微软雅黑", 22, "bold"), foreground=slc["text-color"]["h1"], spacing1=15, spacing3=15)
    ST.tag_config("h2", font=("微软雅黑", 17, "bold"), foreground=slc["text-color"]["h2"], spacing1=14, spacing3=14)
    ST.tag_config("h3", font=("微软雅黑", 16, "bold"), foreground=slc["text-color"]["h3"], spacing1=13, spacing3=13)
    ST.tag_config("h4", font=("微软雅黑", 14, "bold"), foreground=slc["text-color"]["h4"], spacing1=12, spacing3=12)
    ST.tag_config("h5", font=("微软雅黑", 12, "bold"), foreground=slc["text-color"]["h5"], spacing1=11, spacing3=11)
    ST.tag_config("h6", font=("微软雅黑", 11, "bold"), foreground=slc["text-color"]["h6"], spacing1=10, spacing3=10)
    ST.tag_config("line",  font=("微软雅黑", 12), foreground=slc["text-color"]["line"])
    ST.tag_config("date",  font=("微软雅黑", 12), foreground=slc["text-color"]["date"])
    ST.tag_config("default", spacing1=3, spacing3=3)
    ST.tag_config("link", foreground="#0078d7", underline=1)
    ST.tag_config("english", font=("微软雅黑", 12, "italic"))
    ST.tag_config("highlight", background="yellow", foreground="#000000")
    
    def open_link(event):
        index = ST.index("@%s,%s" % (event.x, event.y))
        tag_ranges = ST.tag_prevrange("link", index)
        if tag_ranges:
            link_text = ST.get(tag_ranges[0], tag_ranges[1])
            link_open(link_text)

    def exit_md():
        md.destroy()

    Button(md, text="退出", style="Accent.TButton", command=exit_md).place(anchor="n", rely=1, y=-40, x=100, width=180)

    find_entry = Entry(md, font=("微软雅黑", 10))
    find_entry.place(anchor=tk.NE, relx=1, x=-20, y=-50)

    def find(event):   
        md.unbind("<Control-f>")
        md.unbind("<Control-F>")     
        moveD(find_entry, y=70, add_no_wait=19)
        
        find_entry.config(state="normal")
        find_entry.insert(tk.INSERT, string)
        find_entry.focus_set()

    def search_text(event=None):
        search_term = find_entry.get()
        ST.tag_remove("highlight", "1.0", tk.END)
        if search_term:
            start_pos = "1.0"
            while True:
                start_pos = ST.search(search_term, start_pos, stopindex=tk.END)
                if not start_pos:
                    break
                end_pos = f"{start_pos}+{len(search_term)}c"
                ST.tag_add("highlight", start_pos, end_pos)
                start_pos = end_pos

    def esc(event):
        global string
        md.bind("<Control-f>", find)
        md.bind("<Control-F>", find)
        string = find_entry.get()
        find_entry.place_configure(y=-70)
        
        ST.tag_remove("highlight", "1.0", tk.END)
        find_entry.delete(0, tk.END)
        find_entry.config(state="disabled")

    find_entry.bind("<KeyRelease>", search_text)
    md.bind("<Control-f>", find)
    md.bind("<Control-F>", find)
    md.bind("<Escape>", esc)

    def mainpage():
        ST.delete(1.0, tk.END)
        with open(".docTex/index.dt", "r", encoding="utf-8") as code:
            exec(code.read())
        search_text()
    
    def log():
        ST.delete(1.0, tk.END)
        with open(".docTex/log/log.dt", "r", encoding="utf-8") as code:
            exec(code.read())
        search_text()

    ChooseLabel(md, ("主页", "日志"), func=(mainpage, log), y=20, frame_background="#f3f3f3", cBefore="#f3f3f3", cAfter="#e6e6e6", foreground="#323232", cClick_bg="#cccccc", cClick_fg="#616161")

    sv_ttk.set_theme("light")
    md.mainloop()

if __name__ == "__main__":
    main()