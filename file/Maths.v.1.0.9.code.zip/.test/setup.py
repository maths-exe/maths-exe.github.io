import tkinter as tk
from tkinter.ttk import *
import sv_ttk
from threading import Thread
from PIL import ImageTk, Image

class ChooseLabel:
    def __init__(self, master, text: tuple, y=0, background="#ffffff", anchor=tk.NW, cBefore="#000000", cAfter="#f3f3f3", width=200, c="#5a5a5a",foreground="#000000", c2="#eaeaea"):
        self.frame = tk.Frame(master=master, background=background)
        self.frame.place(y=y, anchor=anchor, width=width, height=len(text) * 34)
        
        self.buttons = []
        self.current_button = None  # 用于跟踪当前被按下的按钮
        for i in range(len(text)):
            button = Label(self.frame, text=f"   {text[i]} ", justify="left", font=("微软雅黑", 10), background=cBefore, foreground=foreground)
            button.place(anchor=tk.NW, x=5, y=i * 34, width=190, height=30)
            button.bind("<Enter>", lambda event, btn=button: btn.config(background=cAfter, foreground=foreground))
            button.bind("<Leave>", lambda event, btn=button: btn.config(background=cBefore if btn != self.current_button else c2, foreground=foreground))
            button.bind("<Button-1>", lambda event, btn=button, idx=i: self.on_button_click(btn, idx, c2, c, foreground, cBefore))
            self.buttons.append(button)
        self.line = Label(self.frame, background="#005a9e")
        self.line.place(height=15, width=2, anchor=tk.E, y=15, x=6)

        # 默认点击第一个按钮
        if self.buttons:
            self.on_button_click(self.buttons[0], 0, c2, c, foreground, cBefore)

    def on_button_click(self, button, index, c2, c, foreground, cBefore):
        if self.current_button:
            self.current_button.config(background=cBefore, foreground=foreground)
        button.config(background=c2, foreground=c)
        self.current_button = button
        self.animate_line(index * 34 + 13)

    def animate_line(self, target_y):
        current_y = self.line.winfo_y()
        step = (target_y - current_y) / 10  # 缓冲效果
        def move():
            nonlocal current_y
            if abs(target_y - current_y) > 1:
                current_y += step
                self.line.place(y=current_y)
                self.line.after(10, move)
            else:
                self.line.place(y=target_y)
        move()

def main():
    md = tk.Tk()
    global line
    line = ImageTk.PhotoImage(Image.open(".docTex/source/line.dtf"))

    ChooseLabel(md, ("主页", "其他", "退出", "Test1", "Test2", "Test3"), y=20, background="#f3f3f3", cBefore="#f3f3f3", cAfter="#e6e6e6",foreground="#323232", c2="#cccccc")

    md.title("docTex")

    md.config(background="#f3f3f3")
    md.wm_minsize(width=768, height=475)

    Label(md, background="#f9f9f9").place(x=200, width=20, relheight=1)
    Label(md, background="#f9f9f9").place(anchor="ne", relx=1, width=20, relheight=1)
    Label(md, background="#dadada").place(x=200, width=1, relheight=1)
    scrollbor = Scrollbar(md)
    scrollbor.place(anchor=tk.NE, relx=1, relheight=1, x=5)
    ST = tk.Text(md, background="#f9f9f9", borderwidth=0, fg="#323232", relief=tk.FLAT, cursor="arrow", font=("微软雅黑", 12), undo=False, takefocus=False,
                   insertwidth=1, selectbackground="#e0e0e0", selectforeground="#000000", yscrollcommand=scrollbor.set,
                      )
    ST.place(relwidth=1, relheight=1, width=-240, x=220)
    ST.bind("<Button-1>", lambda f:"break")
    scrollbor["command"] = ST.yview

    with open(".docTex/index.dt", "r", encoding="utf-8") as code:
        exec(code.read())
    
    def reload():
        ST.delete(1.0, tk.END)
        with open(".docTex/index.dt", "r", encoding="utf-8") as code:
            exec(code.read())

    ST.tag_config("h1", font=("微软雅黑", 22, "bold"), foreground="#323232", spacing1=15, spacing3=15)
    ST.tag_config("h2", font=("微软雅黑", 17, "bold"), foreground="#323232", spacing1=14, spacing3=14)
    ST.tag_config("h3", font=("微软雅黑", 16, "bold"), foreground="#323232", spacing1=13, spacing3=13)
    ST.tag_config("h4", font=("微软雅黑", 14, "bold"), foreground="#323232", spacing1=12, spacing3=12)
    ST.tag_config("h5", font=("微软雅黑", 12, "bold"), foreground="#323232", spacing1=11, spacing3=11)
    ST.tag_config("h6", font=("微软雅黑", 11, "bold"), foreground="#323232", spacing1=10, spacing3=10)
    ST.tag_config("line",  font=("微软雅黑", 12), foreground="#7c7c7c")
    ST.tag_config("default", spacing1=3, spacing3=3)

    Button(md, text="重载", style="Accent.TButton", command=reload).place(anchor="n", rely=1, y=-40, x=100, width=180)

    sv_ttk.set_theme("light")
    md.mainloop()


if __name__ == "__main__":
    main()