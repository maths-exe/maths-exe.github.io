"""class docTex:
    def __init__(self, master:tk.Text, docTex_text:str):
        self.docTex_text = docTex_text.split("\n")
        self.master = master
        

    def showText(self):
        ALL_mark = ("h1", "h2", "h3", "h4", "h5", "h6", "line")

        def loop():
            for i in self.docTex_text:
                mark = i.split(" -")[-1]
                if mark in ALL_mark:
                    if mark == "line":
                        self.master.image_create(tk.INSERT, image=line)
                        self.master.insert(tk.INSERT, "  ")
                        self.master.insert(tk.INSERT, " -".join(i.split(" -")[:-1])+"\n", mark)
                    else:
                        self.master.insert(tk.INSERT, " -".join(i.split(" -")[:-1])+"\n", mark)
                else:
                    self.master.insert(tk.INSERT, i+"\n", "default")
            return "break"
        self.th = Thread(target=loop, daemon=True)
        self.th.start()

        self.master.tag_config("h1", font=("微软雅黑", 22, "bold"), foreground="#323232", spacing1=15, spacing3=15)
        self.master.tag_config("h2", font=("微软雅黑", 17, "bold"), foreground="#323232", spacing1=14, spacing3=14)
        self.master.tag_config("h3", font=("微软雅黑", 16, "bold"), foreground="#323232", spacing1=13, spacing3=13)
        self.master.tag_config("h4", font=("微软雅黑", 14, "bold"), foreground="#323232", spacing1=12, spacing3=12)
        self.master.tag_config("h5", font=("微软雅黑", 12, "bold"), foreground="#323232", spacing1=11, spacing3=11)
        self.master.tag_config("h6", font=("微软雅黑", 11, "bold"), foreground="#323232", spacing1=10, spacing3=10)
        self.master.tag_config("line",  font=("微软雅黑", 12), foreground="#7c7c7c")

        
        self.master.tag_config("default", spacing1=3, spacing3=3)"""