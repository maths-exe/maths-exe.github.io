from matplotlib import mathtext
from matplotlib import font_manager

prop = font_manager.FontProperties(math_fontfamily="stix", size=11)

#print([item.name for item in font_manager.fontManager.ttflist])

mathtext.math_to_image(r"""$x+2=6$""", r"a.jpg", prop=prop)

"""def inserts(n):
        while 1:
            if search.get() == "":
                search.insert(INSERT, "搜索")
                search.icursor(0)
                search["fg"] = style["SearchW"]["Text"]
            if search.get() == "搜索" and search.cget("fg") == style["SearchW"]["Text"]:
                search.icursor(0)
            else:
                search["fg"] = style["SearchW"]["Text2"]
                if search.get()[:-2] != "":
                    search.delete(INSERT, END)
                else:
                    pass
            sleep(0.001)"""


"代数的平衡"
# TextFore2->h2
# TextFore5->h3
# TextFore3->lon

# Label(self.frame2, text="", justify='left', fg=style["CanvasW"]["TextFore"], bg=style["CanvasW"]["Background"]).pack(anchor=NW)

Label(self.frame2, text="\n\n\n\n\n\n\n代数平衡", fg=style["ChooseUI"], bg=style["CanvasW"]["Background"], font=("黑体", 25)).pack()
Label(self.frame2, text="代数非常有趣 - 可以解决难题!\n\n\n", fg=style["CanvasW"]["TextFore"], bg=style["CanvasW"]["Background"], font=("黑体", 10, "italic")).pack()
Label(self.frame2, text="当我们从两边添加或减去相同的事物时,使等式保持平衡.\n\n观察下面的方程式,并尝试使用+x,−x,+1,−1按钮得到随机的等式.\n\n\n", justify='left', fg=style["CanvasW"]["TextFore"], bg=style["CanvasW"]["Background"]).pack(anchor=NW)

frame_t1 = Frame(self.frame2, width=300, height=200, bg=style["CanvasW"]["Background2"], highlightthickness=1, highlightbackground=style["CanvasW"]["HighLightBack3"])
frame_t1.pack()

x_c      = -5
X_C      = 5
X_c1     = randint(x_c, X_C)
X_c2     = randint(x_c, X_C)
X_var_c1 = randint(x_c, X_C)
X_var_c2 = X_var_c1 - 1
    

label_t1 = Label(frame_t1, text=f"{X_var_c1}x+{X_c1}={X_var_c2}x+{X_c2}".replace("+-", "-").replace("1x", "x").replace("0x", ""), font=("Bodoni MT", 14, "italic"), width=20, bg=style["CanvasW"]["Background3"])
label_t1.place(anchor='center', relx=0.5, rely=0.8)

def EQU(event):
    global X_var_c1, X_var_c2, X_c1, X_c2, x_c, X_C, label_t1
    X_c1     = randint(x_c, X_C)
    X_c2     = randint(x_c, X_C)
    X_var_c1 = randint(x_c, X_C)
    X_var_c2 = X_var_c1 - 1
    print(f"{X_c1}+{X_var_c1}x={X_c2}+{X_var_c2}x")
    label_t1["text"] = f"{X_var_c1}x+{X_c1}={X_var_c2}x+{X_c2}"{X_c2}+{X_var_c2}x".replace("+-", "-").replace("1x", "x").replace("0x", "")


new_EQU = Lutton(frame_t1, text=" 新的等式 ")
new_EQU.binding(EQU)
new_EQU.place(anchor="ne", relx=1, x=-10, y=10)

Label(frame_t1, bg=style["CanvasW"]["Background4"]).place(x=5, y=5, width=83, height=53)

def add_x(event):
    global X_var_c1, X_var_c2, label_t1
    X_var_c1 += 1
    X_var_c2 += 1
    print(f"{X_c1}+{X_var_c1}x={X_c2}+{X_var_c2}x")
    label_t1["text"] = f"{X_var_c1}x+{X_c1}={X_var_c2}x+{X_c2}"{X_c2}+{X_var_c2}x".replace("+-", "-").replace("1x", "x").replace("0x", "")
def hex_x(event):
    global X_var_c1, X_var_c2, label_t1
    X_var_c1 -= 1
    X_var_c2 -= 1
    print(f"{X_c1}+{X_var_c1}x={X_c2}+{X_var_c2}x")
    label_t1["text"] = f"{X_var_c1}x+{X_c1}={X_var_c2}x+{X_c2}"{X_c2}+{X_var_c2}x".replace("+-", "-").replace("1x", "x").replace("0x", "")
def add_c(event):
    global X_c1, X_c2, label_t1
    X_c1 += 1
    X_c2 += 1
    print(f"{X_c1}+{X_var_c1}x={X_c2}+{X_var_c2}x")
    label_t1["text"] = f"{X_var_c1}x+{X_c1}={X_var_c2}x+{X_c2}"{X_c2}+{X_var_c2}x".replace("+-", "-").replace("1x", "x").replace("0x", "")
def hex_c(event):
    global X_c1, X_c2, label_t1
    X_c1 -= 1
    X_c2 -= 1
    print(f"{X_c1}+{X_var_c1}x={X_c2}+{X_var_c2}x")
    label_t1["text"] = f"{X_var_c1}x+{X_c1}={X_var_c2}x+{X_c2}"{X_c2}+{X_var_c2}x".replace("+-", "-").replace("1x", "x").replace("0x", "")

new_add_x = Lutton(frame_t1, text=" +x ", highlightbackground=style["CanvasW"]["Background4"])
new_add_x.binding(add_x)
new_add_x.place(anchor="nw", x=10, y=10)
new_hex_x = Lutton(frame_t1, text=" -x ", highlightbackground=style["CanvasW"]["Background4"])
new_hex_x.binding(hex_x)
new_hex_x.place(anchor="nw", x=10, y=32)
new_add_c = Lutton(frame_t1, text=" +1 ", highlightbackground=style["CanvasW"]["Background4"])
new_add_c.binding(add_c)
new_add_c.place(anchor="nw", x=47, y=10)
new_hex_c = Lutton(frame_t1, text=" -1 ", highlightbackground=style["CanvasW"]["Background4"])
new_hex_c.binding(hex_c)
new_hex_c.place(anchor="nw", x=47, y=32)


try:
    for i in self.frame2.winfo_children():
        i.bind("<MouseWheel>", wheel)
except:
    for i in sf.frame2.winfo_children():
        i.bind("<MouseWheel>", wheel)





























