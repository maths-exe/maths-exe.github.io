from tkinter import *
from PIL import ImageTk, Image
from threading import Thread
root = Tk()
root.title("Combobox Example")
root.geometry('300x300')

global image_setup_1
image_setup_1 = ImageTk.PhotoImage(Image.open(".image/icon/image64.jpeg"))
_img = Label(root, image=image_setup_1)
_img.place(anchor=CENTER, relx=0.5, rely=0.5)

class conputlib:
   def __init__(self, master,  c0:tuple, c1:tuple, step, wait_time=0):
      self.master= master
      self.N = -1
      self.c0 = c0
      self.c1 = c1
      self.RGB = self.R = self.G = self.B = self.color = None

      def _func():
         self.N += 1
         self.RGB = (
            self.c0[0]+(self.c1[0]-self.c0[0]) * self.N / step,
            self.c0[1]+(self.c1[1]-self.c0[1]) * self.N / step,
            self.c0[2]+(self.c1[2]-self.c0[2]) * self.N / step
         )
         self.R = hex(int(self.RGB[0])).replace("0x", "")
         self.G = hex(int(self.RGB[1])).replace("0x", "")
         self.B = hex(int(self.RGB[2])).replace("0x", "")
         if len(self.R) == 1:
            self.R = "0" + self.R
         if len(self.G) == 1:
            self.G = "0" + self.G
         if len(self.B) == 1:
            self.B = "0" + self.B

         self.master["bg"] = f"#{self.R}{self.G}{self.B}"

         if self.N == step:
            return 0
         
         root.after(10, _func)
      root.after(wait_time, _func)

conputlib(root, (255, 255, 255), (28, 123, 167), 50)
conputlib(_img, (255, 255, 255), (28, 123, 167), 50)
root.mainloop()

