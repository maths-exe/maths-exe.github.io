from tkinter import *
from PIL import ImageTk, Image
from tkinter.font import nametofont
from time import sleep
from threading import Thread
import tkinter.ttk as t
from os import listdir
from random import randint
from re import match
from configparser import ConfigParser

Config = ConfigParser()
Config.read(".settings/OptionShow.cfg")

# 内容
def get(file):
    result = open(file=file, mode="r", encoding="utf-8").read()
    return eval(result)
def get2(file):
    result = open(file=file, mode="r", encoding="utf-8").read()
    return result
def setconfig(setname, write):
    file = open(f".settings/{setname}.set", mode="w+", encoding="utf-8")
    file.read()
    file.write(write)
    file.close()
def setget(setname, mode=2):
    result = open(file=f".settings/{setname}.set", mode="r", encoding="utf-8").read()
    if mode == 1:
        return eval(result)
    elif mode == 2:
        return int(result)
    elif mode == 3:
        return result
def font(size):
    return ("黑体", size)

# 读取文件
style = get(".style/light.style")
# 定义
allfilenum = get2(".include/AllFileNumber.set")
file = [".include/algebra/", ".include/calculus/", ".include/data/", ".include/geometry/", ".include/physics/", ".include/numbers/"]
search_file = []
search = []

lang = get(".settings/langauge/zh_CN.lang")

MainWidth = 700

width  = 200
width1 = 0
width2 = 0
width3 = 200

width4 = 200
width5 = 0
width6 = 200

# class
class lButton(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)

    def binding(self, function):
        def leave(event):
            self["background"] = style["lButton"]["Before"]["TextBack"]
            self["foreground"] = style["lButton"]["Before"]["TextFore"]
            self.config(highlightthickness=0)
        def enter(event):
            self["background"] = style["lButton"]["Pass"]["TextBack"]
            self.config(highlightthickness=1, highlightbackground=style["lButton"]["HighLightBack"])

        self.bind("<Leave>", leave)
        self.bind("<Enter>", enter)
        self.bind("<Button-1>", function)
    def acter(self):
        self["background"] = style["lButton"]["After"]["TextBack"]
class LightLabel(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)
    def light(self):
        self.red   = 255
        self.green = 255
        self.blue  = 255
        def color():
            self.config(fg=f"#{hex(self.red)[2:]+hex(self.green)[2:]+hex(self.blue)[2:]}")
            self.red   -= 1
            self.green -= 1
            self.blue  -= 1
            if self.red <= 0:
                return color2()
            elif len(hex(self.red)[2:]) == 1:
                self.config(fg=f"#0{hex(self.red)[2:]}0{hex(self.green)[2:]}0{hex(self.blue)[2:]}")
            self.master.after(2, color)        
        def color2():
            self.config(fg=f"#0{hex(self.red)[2:]}0{hex(self.green)[2:]}0{hex(self.blue)[2:]}")
            self.red   += 1
            self.green += 1
            self.blue  += 1
            if self.red >= 255:
                return color()
            elif len(hex(self.red)[2:]) == 2:
                self.config(fg=f"#{hex(self.red)[2:]+hex(self.green)[2:]+hex(self.blue)[2:]}")
            self.master.after(2, color2)
        color()
class LButton(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)
    def binding(self, func):
        self.config(highlightthickness=1, highlightbackground=style["CanvasW"]["HighLightBack2"])
        def leave(event):
            self.config(highlightbackground=style["CanvasW"]["HighLightBack2"])
        def enter(event):
            self.config(highlightbackground=style["CanvasW"]["HighLightBack"])
        self.bind("<Leave>", leave)
        self.bind("<Enter>", enter)
        try:
            self.bind("<Button-1>", func)
        except:
            pass
    def unbinding(self):
        self.unbind("<Leave>")
        self.unbind("<Enter>")
        try:
            self.unbind("<Button-1>")
        except:
            pass

class Choose:
    def __init__(self, true:LButton, false:tuple):
        self.true = true
        self.false = false
        def true_anwser(event):
            self.true.config(highlightbackground="#2ee62e")
            self.true.unbinding()
            for i in self.false:
                i.unbinding()
        def false_answer1(event):
            self.true.config(highlightbackground="#2ee62e")
            self.false[0].config(highlightbackground="#e62100")
            self.true.unbinding()
            for i in self.false:
                i.unbinding()
        def false_answer2(event):
            self.true.config(highlightbackground="#2ee62e")
            self.false[1].config(highlightbackground="#e62100")
            self.true.unbinding()
            for i in self.false:
                i.unbinding()
        def false_answer3(event):
            self.true.config(highlightbackground="#2ee62e")
            self.false[2].config(highlightbackground="#e62100")
            self.true.unbinding()
            for i in self.false:
                i.unbinding()
        
        self.true.binding(true_anwser)
        i = 0
        for w in self.false:
            i += 1
            exec(f"w.binding(false_answer{i})")

class Lutton(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)
    def binding(self, function):
        self.config(highlightthickness=1, highlightbackground=style["CanvasW"]["HighLightBack2"])
        def leave(event):
            self.config(highlightbackground=style["CanvasW"]["HighLightBack2"])
        def enter(event):
            self.config(highlightbackground=style["CanvasW"]["HighLightBack"])
        self.bind("<Leave>", leave)
        self.bind("<Enter>", enter)
        try:
            self.bind("<Button-1>", function)
        except:
            pass
class lon(Label):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'label', cnf, kw)
    def binding(self, type):
        if type == 1:
        #self.config(highlightthickness=1, highlightbackground=style["CanvasW"]["HighLightBack2"])
            def leave(event):
                self.config(bg=style["CanvasW"]["Background1"])
            def enter(event):
                self.config(bg=style["CanvasW"]["Background2"])
        elif type == 2:
            def leave(event):
                self.config(fg=style["CanvasW"]["TextFore3"])
            def enter(event):
                self.config(fg=style["CanvasW"]["TextFore4"])

        self.bind("<Leave>", leave)
        self.bind("<Enter>", enter)

class FrameRead(Text):
    def __init__(self, master=None, cnf={}, **kw):
        Widget.__init__(self, master, 'text', cnf, kw)
    def binding(self):
        self["relief"] = FLAT
        self["cursor"] = 'arrow'
        def disable_text_selection(event):
            return "break"
        self.bind("<Button-1>", disable_text_selection)
    def read(self, file):
        exec('\n'.join(open(file=file, mode="r", encoding="utf-8").read().split("\n")[0:]))
    def clear(self):
        self.delete(1.0, END)

class ScrollbarFrame(Canvas):
    def __init__(self, master=None, **kw):
        self.frame = Frame(master)
        self.vbar = Scrollbar(self.frame)
        self.vbar.pack(side=RIGHT, fill=Y)

        kw.update({'yscrollcommand': self.vbar.set})

        Canvas.__init__(self, self.frame, **kw)
        self.pack(side=LEFT, fill=BOTH, expand=True)
        self.vbar['command'] = self.yview

        def myfunction(event):
            self.configure(scrollregion=self.bbox("all"), highlightthickness=0, relief=FLAT, bd=0)
        self.frame2 = Frame(self, highlightthickness=0, relief=FLAT)
        self.__important__ = self.create_window((0,0), window=self.frame2, anchor=N, width=700)
        
        global wheel

        def wheel(event):
            if self.vbar.get() == (0.0, 1.0):
                pass
            else:
                self.yview_scroll(-1*(int(event.delta/120)), "units")

        self.frame2.bind("<MouseWheel>", wheel)
        self.bind("<MouseWheel>", wheel)
        self.frame2.bind("<Configure>", myfunction)

        text_meths = vars(Canvas).keys()
        methods = vars(Pack).keys() | vars(Grid).keys() | vars(Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

    def do(self, type=2):
        def loop():
            while 1:
                try:
                    if type == 1:
                        width = int(self.canvasx(self.winfo_width()/2))
                        self.coords(self.__important__, width, 0)
                    elif type == 2:
                        width = self.winfo_width()
                        self.itemconfig(self.__important__, width=width)
                    sleep(0.00001)
                except:
                    break
        self.th = Thread(target=loop, daemon=True)
        self.th.start()

    def read(self, filepath):
       file = open(file=filepath, mode="r", encoding="utf-8")
       exec(file.read())
       file.close()

    def binding(self, color):
        self.frame2['bg'] = color

def run(file):
    file = open(file=file, mode="r", encoding="utf-8")
    exec(file.read())
    file.close()
    return 0

# 读取文件
openedc = Tk()
openedc.overrideredirect(1)
openedc.geometry(f"450x300+{int(openedc.winfo_screenwidth()/2)-225}+{int(openedc.winfo_screenheight()/2)-150}")
bgimage1 = ImageTk.PhotoImage(Image.open(".image/background/image2.ms"))
temp = Label(openedc, image=bgimage1)
temp["image"] = bgimage1
temp.place(anchor="center", relx=0.5, rely=0.5)
percent = Label(openedc, bg="#198cc1", fg="#eeeeee")
percent.place(anchor="se", relx=1, rely=1, x=-10, y=-10)
Label(openedc, text=f"version:{get2('version.set')}", bg="#198cc1", fg="#eeeeee").place(anchor=NE, relx=1, y=10, x=-10)
"""tempnum1 = -1
tempnum2 = -1
tempnum3 = 0
def per_cent():
    global tempnum1
    tempnum1 += 1
    if tempnum1 == len(file):
        openedc.after(1000)
        #print(search)
        openedc.destroy()
        return 0
    else:
        _list = listdir(file[tempnum1])
    def per_cent2():
        global tempnum2, tempnum3
        tempnum2 += 1
        if tempnum2 == len(_list):
            tempnum2 = -1
            openedc.after(1, per_cent)
        else:
            tempnum3 += 1
            percent["text"] = f"{str(tempnum3/int(allfilenum)*100).split('.')[0]}%"
            readfile = open(file=f"{file[tempnum1]}{_list[tempnum2]}", mode="r", encoding="utf-8").readline().split("\n")[0].replace('"',"")
            search.append(readfile)
            #print(readfile)
            search_file.append(_list[tempnum2])
            openedc.after(1, per_cent2)
    if str(_list) == '[]':
        openedc.after(1, per_cent)
    else:
        per_cent2()"""
#per_cent()
def temp():
    def b():
        openedc.destroy()
    openedc.after(1000, b)
temp()
openedc.mainloop()
# 主体
def main():
    global w, C_1
    w = Tk()
    # 设置
    w.title("Maths_Test")
    w.config(background=style["TextBack"])
    w.geometry(f"{setget('WindowSize', 3)}+{int(w.winfo_screenwidth()/2)-384}+{int(w.winfo_screenheight()/2)-238}")
    # 图标
    w.iconbitmap(".image/icon/image64.ico")
    w.wm_iconbitmap(".image/icon/image64.ico")
    w.wm_minsize(width=768, height=475)
    # 全局字体
    default_font2 = nametofont("TkDefaultFont")
    default_font2.configure(family="黑体", size=10)
    # 菜单
    MainUI = Frame(w, bg=style["ChooseUI"], width=200)
        #MainUI['bg']='red'
    MainUI.place(anchor=NW, x=0, y=0, relheight=1)
    # 显示
    MathIsFun = Label(MainUI, bg=style["ChooseUI"], fg=style["TextFore2"], text="Maths", font=("宋体", 18))
    MathIsFun.place(anchor=NW, x=10, y=10)
        #Label(w, bg=style["TextBack"], fg=style["TextFore3"], text="Mathematics", font=("黑体", 10)).place(anchor="se", relx=1, rely=1, y=-10, x=-10)
    
    iconimage1 = ImageTk.PhotoImage(Image.open(".image/icon/C-1.ms"))
    iconimage2 = ImageTk.PhotoImage(Image.open(".image/icon/C-2.ms"))
    C_1 = Label(MainUI, bg="#198cc1", fg="#ffffff", image=iconimage1, width=14, height=14)
    C_1["image"] = iconimage1
    def enter(event):
        C_1["image"] = iconimage1
    def leave(event):
        C_1["image"] = iconimage2
    C_1.bind("<Leave>", enter)
    C_1.bind("<Enter>", leave)
    
    # 搜索框函数
    def no_button(event):
        search.insert(INSERT, lang["10001"]+lang["00001"])
        search.icursor(0)
        search["fg"] = style["SearchW"]["Text"]
    search = Entry(MainUI, relief=FLAT, highlightthickness=1, highlightbackground=style["SearchW"]["Before"], insertwidth=1)
    search.place(anchor='center', x=100, y=60, width=190)
    no_button(1)
    search.config(state="disabled")
    text1 = FrameRead(w, bg=style["TextBack"], font="黑体")
    text1.place(anchor=NE, relx=1, relheight=1, relwidth=1, width=-202)
    text1.binding()
    # 函数
    global useless
    def useless(event):
        pass
    def close(event):
        if Config.get("Startup", "Size") == "2":
            setconfig(f"WindowSize", f"{w.winfo_width()}x{w.winfo_height()}")
        Z.acter()
        w.destroy()
    def settings(event):
        global Set_x
        Set_x = 30
        A.acter()
        Set = Frame(w, bg=style["Settings"]["Background"])
        Set.place(relheight=1, relwidth=1, y=30, anchor=NW)
        def do():
            global Set_x
            Set_x -= 1
            if Set_x == -1:
                Set_x = 0
                return 0
            Set.place_configure(y=Set_x)
            w.after(1, do)
        w.after(50, do)
        def do2():
            global Set_x
            Set_x += 1
            if Set_x == 31:
                Set_x = 30
                return Set.destroy()
            Set.place_configure(y=Set_x)
            w.after(1, do2)

        settingsnum = []
        def exite(event):
            w.after(50, do2)
        def loade(event):
            configset = open(file=".settings/OptionShow.cfg", mode="w")
            Config.write(configset)

        SetUI = ScrollbarFrame(Set, bg=style["Settings"]["Background"])
        SetUI.binding(style["Settings"]["Background"])
        SetUI.do()
        SetUI.place(relheight=1, relwidth=1, height=-50)

        line = Label(Set, bg='#565656').place(rely=1, y=-50, height=1, relwidth=1)

        loadk = lButton(Set, text="保存", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        loadk.place(anchor="center", relx=1, rely=1, y=-25, x=-130, width=60)
        loadk.binding(loade)
        exitk = LButton(Set, text="退出")
        exitk.place(anchor="center", relx=1, rely=1, y=-25, x=-60, width=60)
        exitk.binding(exite)

        class SetFrame(LabelFrame):
            def __init__(self, master=None, cnf={}, **kw):
                Widget.__init__(self, master, 'labelframe', cnf, kw)
                self.pack(fill=BOTH, padx=20, pady=2)
            def show(self, text1, text2):
                Label(self, text=text1, bg=style["Settings"]["Background"], fg=style["Settings"]["Foreground"]).grid(sticky="nw")
                Label(self, text=text2, bg=style["Settings"]["Background"], fg=style["Settings"]["Foreground2"], font=("黑体", 9)).grid(sticky="nw")
        
        Label(SetUI.frame2, text="启动", bg=style["Settings"]["Background"], fg=style["Settings"]["Foreground"], font=("黑体", 20, "bold")).pack(anchor=NW, padx=10, pady=5)

        _01 = SetFrame(SetUI.frame2, bg="#ffffff", highlightthickness=1, highlightbackground="#ddd", relief=FLAT)
        _01.show("启动大小", "启动时窗口的大小。")
        
        _01slist = ("默认", "自定义", "不设置")
        combox1 = t.Combobox(_01, values=_01slist)
        combox1.place(anchor="e", rely=0.5, relx=1, x=-5)
        print(_01slist[int(Config.get("Startup", "Size"))], Config.get("Startup", "Size"))
        combox1.insert(INSERT, _01slist[int(Config.get("Startup", "Size"))])

        def option_selected(event):
            selected_option = combox1.get()
            if settingsnum.count("0.0") != 0:
                del settingsnum[settingsnum.index("0.0")]
            elif settingsnum.count("0.1") != 0:
                del settingsnum[settingsnum.index("0.1")]
            elif settingsnum.count("0.2") != 0:
                del settingsnum[settingsnum.index("0.2")]
                
            if selected_option == "默认":
                Config.set("Startup", "Size", "0")
                settingsnum.append("0.0")
            elif selected_option == "自定义":
                Config.set("Startup", "Size", "1")
                settingsnum.append("0.1")
            elif selected_option == "不设置":
                Config.set("Startup", "Size", "2")
                settingsnum.append("0.2")    

        combox1["state"] = 'readonly'
        combox1.bind("<<ComboboxSelected>>", option_selected)

        _02 = SetFrame(SetUI.frame2, bg="#ffffff", highlightthickness=1, highlightbackground="#ddd", relief=FLAT)
        _02.show("启动位置", "启动时窗口的右上角的位置。")
        _03 = SetFrame(SetUI.frame2, bg="#ffffff", highlightthickness=1, highlightbackground="#ddd", relief=FLAT)
        _03.show("语言(需重新启动)", "选择应用程序的显示语言。")



    def about(event):
        B.acter()
        global width2
        AboutCUI = Frame(w, bg=style["ChooseUI"])
        AboutCUI.place(relheight=1, height=-80, y=80, anchor=NW)
        def MathCUIplus3():
            global width2
            width2 += 2#plus
            AboutCUI.place_configure(width=width2)
            if width2 >= 200:
                ChooseUI.place_forget()
                Back3.place(anchor="s", x=100, rely=1, y=-10, width=160.0, height=30)
                return 0
            w.after(1, MathCUIplus3)
        MathCUIplus3()
        def back3(event):
            Back3.acter()
            text1.clear()
            ChooseUI.place(relheight=1, height=-80, y=80, anchor=NW, width=width)
            def MathCUIadd3():
                global width2
                width2 -= 2#add
                AboutCUI.place_configure(width=width2)
                if width2 <= 0:
                    AboutCUI.destroy()
                    return 0
                w.after(1, MathCUIadd3)
            MathCUIadd3()
        text1.read(".include/about/about1.frame")
        Back3 = lButton(AboutCUI, text=lang["10002"], compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Back3.binding(back3)
        
    def math1(event):
        C.acter()
        global width1
        MathCUI = Frame(w, bg=style["ChooseUI"])
        MathCUI.place(relheight=1, height=-80, y=80, anchor=NW)
        def MathCUIplus1():
            global width1
            width1 += 2#plus
            MathCUI.place_configure(width=width1)
            if width1 >= 200:
                ChooseUI.place_forget()
                Algebra.place(anchor="n", x=100, y=0, width=160.0, height=30)
                Calculus.place(anchor="n", x=100, y=30, width=160.0, height=30)
                Data.place(anchor="n", x=100, y=60, width=160.0, height=30)
                Geometry.place(anchor="n", x=100, y=90, width=160.0, height=30)
                Physics.place(anchor="n", x=100, y=120, width=160.0, height=30)
                Numbers.place(anchor="n", x=100, y=150, width=160.0, height=30)
                Back.place(anchor="s", x=100, rely=1, y=-10, width=160.0, height=30)
                return 0
            w.after(1, MathCUIplus1)
        MathCUIplus1()
        def back(event):
            Back.acter()
            Algebra.place_forget()
            Calculus.place_forget()
            Data.place_forget()
            Geometry.place_forget()
            Physics.place_forget()
            Numbers.place_forget()
            ChooseUI.place(relheight=1, height=-80, y=80, anchor=NW, width=width)
            def MathCUIadd1():
                global width1
                width1 -= 2#add
                MathCUI.place_configure(width=width1)
                if width1 <= 0:
                    MathCUI.destroy()
                    return 0
                w.after(1, MathCUIadd1)
            MathCUIadd1()
        def math2(event):
            global width3, c_1button_1_1, Algebra_sf
            Algebra.acter()
            width3 = 200
            Algebra.place_forget()
            Calculus.place_forget()
            Data.place_forget()
            Geometry.place_forget()
            Physics.place_forget()
            Numbers.place_forget()
            search.place_forget()
            MathIsFun.place_forget()
            MathCUI.place_configure(width=1)
            text1.place_forget()
            def c_1button_1_1(event):
                search.place(anchor='center', x=100, y=60, width=190)
                MathIsFun.place(anchor=NW, x=10, y=10)
                Algebra_sf.frame.destroy()
                C_1.unbind("<Button>")
                C_1.place_forget()
                def Algebra_SFadd1():
                    global width3
                    width3 += 2#add
                    MainUI.place_configure(width=width3)
                    if width3 >= 200:
                        MathCUI.place_configure(width=200)
                        Algebra.place(anchor="n", x=100, y=0, width=160.0, height=30)
                        Calculus.place(anchor="n", x=100, y=30, width=160.0, height=30)
                        Data.place(anchor="n", x=100, y=60, width=160.0, height=30)
                        Geometry.place(anchor="n", x=100, y=90, width=160.0, height=30)
                        Physics.place(anchor="n", x=100, y=120, width=160.0, height=30)
                        Numbers.place(anchor="n", x=100, y=150, width=160.0, height=30)
                        text1.place(anchor=NE, relx=1, relheight=1, relwidth=1, width=-202)
                        return 0
                    w.after(1, Algebra_SFadd1)
                Algebra_SFadd1()
            def Algebra_SFplus1():
                global width3
                width3 -= 2#add
                MainUI.place_configure(width=width3)
                if width3 <= 40:
                    C_1.place(anchor=S, x=20, rely=1, y=-10)
                    C_1.bind("<Button-1>", c_1button_1_1)
                    Algebra_sf.place(anchor=NW, relheight=1 ,relwidth=1, width=-40, x=40)
                    return 0
                w.after(1, Algebra_SFplus1)
            Algebra_SFplus1()
            # 组件
            Algebra_sf = ScrollbarFrame(w, bg=style["CanvasW"]["Background"])
            Algebra_sf.binding(style["CanvasW"]["Background"])
            Algebra_sf.do()
            Label(Algebra_sf.frame2, text="\n\n代数", fg=style["ChooseUI"], bg=style["CanvasW"]["Background"], font=("黑体", 25)).pack()
            Label(Algebra_sf.frame2, text="代数非常有趣 - 可以解决难题!\n\n", fg=style["CanvasW"]["TextFore7"], bg=style["CanvasW"]["Background"]).pack()
            Label(Algebra_sf.frame2, text="""在电脑游戏中, 你可以通过奔跑, 跳跃和寻找神秘东西来玩. 

在代数中, 你可以玩字母, 数字和符号, 还可以找到其它神秘的东西!

当你学会了一些 "技巧" 时, 弄清楚如何利用你的技能来解决每个问题就变成了一个有趣的挑战. """, justify='left', fg=style["CanvasW"]["TextFore"], bg=style["CanvasW"]["Background"]).pack()
            Label(Algebra_sf.frame2, text="\n\n\n基础知识\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)
            padx = 60
            pady = 2
            class Cooler:
                def __init__(self, a:LButton, file):
                    self.a = a
                    self.file = file
                    def SF(event):
                        global sf, later_a
                        def later_a(event):
                            C_1.bind("<Button-1>", c_1button_1_1)
                            Algebra_sf.frame.place(anchor=NW, relheight=1 ,relwidth=1, width=-40, x=40)
                            sf.frame.destroy()
                        Algebra_sf.frame.place_forget()
                        sf = ScrollbarFrame(w, bg=style["CanvasW"]["Background"])
                        sf.binding(style["CanvasW"]["Background"])
                        sf.do(type=1)
                        sf.place(anchor=NW, relheight=1 ,relwidth=1, width=-40, x=40)
                        sf.read(self.file)
                        C_1.bind("<Button-1>", later_a)
                    self.a.binding(func=SF)
            # A区
            Aa1 = LButton(Algebra_sf.frame2, text="代数简介", bg=style["CanvasW"]["Background"])
            Aa1.pack(anchor=NW, padx=padx, pady=pady)
            Cooler(Aa1, ".include/algebra/algebra2.frame2")
            Aa2 = LButton(Algebra_sf.frame2, text="代数的平衡", bg=style["CanvasW"]["Background"])
            Aa2.pack(anchor=NW, padx=padx, pady=pady)
            Cooler(Aa2, ".include/algebra/animations/animation1.frame2")
            Aa3 = LButton(Algebra_sf.frame2, text="代数乘法", bg=style["CanvasW"]["Background"])
            Aa3.pack(anchor=NW, padx=padx, pady=pady)
            Aa3.binding(useless)
            Aa4 = LButton(Algebra_sf.frame2, text="运算顺序BODMAS", bg=style["CanvasW"]["Background"])
            Aa4.pack(anchor=NW, padx=padx, pady=pady)
            Aa4.binding(useless)
            Aa5 = LButton(Algebra_sf.frame2, text="运算顺序PEMDAS", bg=style["CanvasW"]["Background"])
            Aa5.pack(anchor=NW, padx=padx, pady=pady)
            Aa5.binding(useless)
            Aa6 = LButton(Algebra_sf.frame2, text="代入", bg=style["CanvasW"]["Background"])
            Aa6.pack(anchor=NW, padx=padx, pady=pady)
            Aa6.binding(useless)
            Aa7 = LButton(Algebra_sf.frame2, text="方程式与公式", bg=style["CanvasW"]["Background"])
            Aa7.pack(anchor=NW, padx=padx, pady=pady)
            Aa7.binding(useless)
            Aa8 = LButton(Algebra_sf.frame2, text="不等式", bg=style["CanvasW"]["Background"])
            Aa8.pack(anchor=NW, padx=padx, pady=pady)
            Aa8.binding(useless)
            Aa9 = LButton(Algebra_sf.frame2, text="解决不等式", bg=style["CanvasW"]["Background"])
            Aa9.pack(anchor=NW, padx=padx, pady=pady)
            Aa9.binding(useless)
            Aa10 = LButton(Algebra_sf.frame2, text="基本代数定义", bg=style["CanvasW"]["Background"])
            Aa10.pack(anchor=NW, padx=padx, pady=pady)
            Aa10.binding(useless)

            # B区
            Label(Algebra_sf.frame2, text="\n指数\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)
            
            Ba1 = LButton(Algebra_sf.frame2, text="什么是指数?", bg=style["CanvasW"]["Background"])
            Ba1.pack(anchor=NW, padx=padx, pady=pady)
            Ba1.binding(useless)
            Ba2 = LButton(Algebra_sf.frame2, text="负指数", bg=style["CanvasW"]["Background"])
            Ba2.pack(anchor=NW, padx=padx, pady=pady)
            Ba2.binding(useless)
            Ba3 = LButton(Algebra_sf.frame2, text="代数中的倒数", bg=style["CanvasW"]["Background"])
            Ba3.pack(anchor=NW, padx=padx, pady=pady)
            Ba3.binding(useless)
            Ba4 = LButton(Algebra_sf.frame2, text="平方根", bg=style["CanvasW"]["Background"])
            Ba4.pack(anchor=NW, padx=padx, pady=pady)
            Ba4.binding(useless)
            Ba5 = LButton(Algebra_sf.frame2, text="立方根", bg=style["CanvasW"]["Background"])
            Ba5.pack(anchor=NW, padx=padx, pady=pady)
            Ba5.binding(useless)
            Ba6 = LButton(Algebra_sf.frame2, text="n次根", bg=style["CanvasW"]["Background"])
            Ba6.pack(anchor=NW, padx=padx, pady=pady)
            Ba6.binding(useless)
            Ba7 = LButton(Algebra_sf.frame2, text="不尽根", bg=style["CanvasW"]["Background"])
            Ba7.pack(anchor=NW, padx=padx, pady=pady)
            Ba7.binding(useless)
            Ba8 = LButton(Algebra_sf.frame2, text="简化平方根", bg=style["CanvasW"]["Background"])
            Ba8.pack(anchor=NW, padx=padx, pady=pady)
            Ba8.binding(useless)
            Ba9 = LButton(Algebra_sf.frame2, text="分数指数", bg=style["CanvasW"]["Background"])
            Ba9.pack(anchor=NW, padx=padx, pady=pady)
            Ba9.binding(useless)
            Ba10 = LButton(Algebra_sf.frame2, text="指数定律", bg=style["CanvasW"]["Background"])
            Ba10.pack(anchor=NW, padx=padx, pady=pady)
            Ba10.binding(useless)
            Ba11 = LButton(Algebra_sf.frame2, text="在代数中使用指数", bg=style["CanvasW"]["Background"])
            Ba11.pack(anchor=NW, padx=padx, pady=pady)
            Ba11.binding(useless)
            Ba12 = LButton(Algebra_sf.frame2, text="带有指数的变量", bg=style["CanvasW"]["Background"])
            Ba12.pack(anchor=NW, padx=padx, pady=pady)
            Ba12.binding(useless)
            # C区
            Label(Algebra_sf.frame2, text="\n简化\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)
            Ca1 = LButton(Algebra_sf.frame2, text="展开(去除括号)", bg=style["CanvasW"]["Background"])
            Ca1.pack(anchor=NW, padx=padx, pady=pady)
            Ca1.binding(useless)
            Ca2 = LButton(Algebra_sf.frame2, text="乘以负数", bg=style["CanvasW"]["Background"])
            Ca2.pack(anchor=NW, padx=padx, pady=pady)
            Ca2.binding(useless)
            Ca3 = LButton(Algebra_sf.frame2, text="交换律,结合律和分配律", bg=style["CanvasW"]["Background"])
            Ca3.pack(anchor=NW, padx=padx, pady=pady)
            Ca3.binding(useless)
            Ca4 = LButton(Algebra_sf.frame2, text="交叉相乘", bg=style["CanvasW"]["Background"])
            Ca4.pack(anchor=NW, padx=padx, pady=pady)
            Ca4.binding(useless)
            Ca5 = LButton(Algebra_sf.frame2, text="比例", bg=style["CanvasW"]["Background"])
            Ca5.pack(anchor=NW, padx=padx, pady=pady)
            Ca5.binding(useless)
            Ca6 = LButton(Algebra_sf.frame2, text="正比与反比", bg=style["CanvasW"]["Background"])
            Ca6.pack(anchor=NW, padx=padx, pady=pady)
            Ca6.binding(useless)
            Ca7 = LButton(Algebra_sf.frame2, text="代数中的分数", bg=style["CanvasW"]["Background"])
            Ca7.pack(anchor=NW, padx=padx, pady=pady)
            Ca7.binding(useless)
            # D区
            Label(Algebra_sf.frame2, text="\n保理", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)
            Label(Algebra_sf.frame2, text="保付代理\n\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore"], font=("黑体", 8, "italic")).pack(anchor=NW, padx=20)
            Da1 = LButton(Algebra_sf.frame2, text="保理简介", bg=style["CanvasW"]["Background"])
            Da1.pack(anchor=NW, padx=padx, pady=pady)
            Da1.binding(useless)

            # I插入区
            Label(Algebra_sf.frame2, text="\n对数\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)
            Ia1 = LButton(Algebra_sf.frame2, text="什么是对数?", bg=style["CanvasW"]["Background"])
            Ia1.pack(anchor=NW, padx=padx, pady=pady)
            Ia1.binding(useless)
            Ia2 = LButton(Algebra_sf.frame2, text="对数可以是小数", bg=style["CanvasW"]["Background"])
            Ia2.pack(anchor=NW, padx=padx, pady=pady)
            Ia2.binding(useless)
            Ia3 = LButton(Algebra_sf.frame2, text="对数与指数", bg=style["CanvasW"]["Background"])
            Ia3.pack(anchor=NW, padx=padx, pady=pady)
            Ia3.binding(useless)


            # E区
            Label(Algebra_sf.frame2, text="\n多项式\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)
            
            Ea1 = LButton(Algebra_sf.frame2, text="什么是多项式?", bg=style["CanvasW"]["Background"])
            Ea1.pack(anchor=NW, padx=padx, pady=pady)
            Ea1.binding(useless)
            Ea2 = LButton(Algebra_sf.frame2, text="多项式的加法和减法", bg=style["CanvasW"]["Background"])
            Ea2.pack(anchor=NW, padx=padx, pady=pady)
            Ea2.binding(useless)
            Ea3 = LButton(Algebra_sf.frame2, text="乘以多项式", bg=style["CanvasW"]["Background"])
            Ea3.pack(anchor=NW, padx=padx, pady=pady)
            Ea3.binding(useless)
            Ea4 = LButton(Algebra_sf.frame2, text="多项式长乘法", bg=style["CanvasW"]["Background"])
            Ea4.pack(anchor=NW, padx=padx, pady=pady)
            Ea4.binding(useless)
            Ea5 = LButton(Algebra_sf.frame2, text="有理表达式", bg=style["CanvasW"]["Background"])
            Ea5.pack(anchor=NW, padx=padx, pady=pady)
            Ea5.binding(useless)
            Ea6 = LButton(Algebra_sf.frame2, text="除以多项式", bg=style["CanvasW"]["Background"])
            Ea6.pack(anchor=NW, padx=padx, pady=pady)
            Ea6.binding(useless)
            Ea7 = LButton(Algebra_sf.frame2, text="多项式长除法", bg=style["CanvasW"]["Background"])
            Ea7.pack(anchor=NW, padx=padx, pady=pady)
            Ea7.binding(useless)
            Ea8 = LButton(Algebra_sf.frame2, text="共轭", bg=style["CanvasW"]["Background"])
            Ea8.pack(anchor=NW, padx=padx, pady=pady)
            Ea8.binding(useless)
            Ea9 = LButton(Algebra_sf.frame2, text="分母有理化", bg=style["CanvasW"]["Background"])
            Ea9.pack(anchor=NW, padx=padx, pady=pady)
            Ea9.binding(useless)
            Ea10 = LButton(Algebra_sf.frame2, text="特殊二项式积", bg=style["CanvasW"]["Background"])
            Ea10.pack(anchor=NW, padx=padx, pady=pady)
            Ea10.binding(useless)

            # F区
            Label(Algebra_sf.frame2, text="\n线性方程\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)

            Fa1 = LButton(Algebra_sf.frame2, text="直线方程", bg=style["CanvasW"]["Background"])
            Fa1.pack(anchor=NW, padx=padx, pady=pady)
            Fa1.binding(useless)
            Fa2 = LButton(Algebra_sf.frame2, text="探索直线图像的属性", bg=style["CanvasW"]["Background"])
            Fa2.pack(anchor=NW, padx=padx, pady=pady)
            Fa2.binding(useless)
            Fa3 = LButton(Algebra_sf.frame2, text="笛卡尔坐标", bg=style["CanvasW"]["Background"])
            Fa3.pack(anchor=NW, padx=padx, pady=pady)
            Fa3.binding(useless)

            # G区
            Label(Algebra_sf.frame2, text="\n二次方程\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)

            Ga1 = LButton(Algebra_sf.frame2, text="二次方程", bg=style["CanvasW"]["Background"])
            Ga1.pack(anchor=NW, padx=padx, pady=pady)
            Ga1.binding(useless)
            Ga2 = LButton(Algebra_sf.frame2, text="二次方程求解器", bg=style["CanvasW"]["Background"])
            Ga2.pack(anchor=NW, padx=padx, pady=pady)
            Ga2.binding(useless)
            Ga3 = LButton(Algebra_sf.frame2, text="因式分解求解", bg=style["CanvasW"]["Background"])
            Ga3.pack(anchor=NW, padx=padx, pady=pady)
            Ga3.binding(useless)
            Ga4 = LButton(Algebra_sf.frame2, text="完全平方", bg=style["CanvasW"]["Background"])
            Ga4.pack(anchor=NW, padx=padx, pady=pady)
            Ga4.binding(useless)

            # H区
            Label(Algebra_sf.frame2, text="\n解决应用题\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)

            Ha1 = LButton(Algebra_sf.frame2, text="解决应用题", bg=style["CanvasW"]["Background"])
            Ha1.pack(anchor=NW, padx=padx, pady=pady)
            Ha1.binding(useless)
            Ha2 = LButton(Algebra_sf.frame2, text="解决不等式应用题", bg=style["CanvasW"]["Background"])
            Ha2.pack(anchor=NW, padx=padx, pady=pady)
            Ha2.binding(useless)

            # J区
            Label(Algebra_sf.frame2, text="\n函数\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)
            Ja1 = LButton(Algebra_sf.frame2, text="函数的定义", bg=style["CanvasW"]["Background"])
            Ja1.pack(anchor=NW, padx=padx, pady=pady)
            Ja1.binding(useless)

            # K区
            Label(Algebra_sf.frame2, text="\n数列和数级\n", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore2"], font=("黑体", 14)).pack(anchor=NW, padx=20)
            Ka1 = LButton(Algebra_sf.frame2, text="数列和数级", bg=style["CanvasW"]["Background"])
            Ka1.pack(anchor=NW, padx=padx, pady=pady)
            Ka1.binding(useless)
            Ka2 = LButton(Algebra_sf.frame2, text="数列 - 找规律", bg=style["CanvasW"]["Background"])
            Ka2.pack(anchor=NW, padx=padx, pady=pady)
            Ka2.binding(useless)
            Ka3 = LButton(Algebra_sf.frame2, text="数列差异工具", bg=style["CanvasW"]["Background"])
            Ka3.pack(anchor=NW, padx=padx, pady=pady)
            Ka3.binding(useless)

            Label(Algebra_sf.frame2, text="\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", justify='left', fg=style["CanvasW"]["TextFore"], bg=style["CanvasW"]["Background"]).pack(anchor=NW)

            for i in Algebra_sf.frame2.winfo_children():
                i.bind("<MouseWheel>", wheel)

        def math3(event):
            global width4, c_1button_1_2
            Calculus.acter()
            width4 = 200
            Algebra.place_forget()
            Calculus.place_forget()
            Data.place_forget()
            Geometry.place_forget()
            Physics.place_forget()
            Numbers.place_forget()
            search.place_forget()
            MathIsFun.place_forget()
            MathCUI.place_configure(width=1)
            text1.place_forget()
            def c_1button_1_2(event):
                search.place(anchor='center', x=100, y=60, width=190)
                MathIsFun.place(anchor=NW, x=10, y=10)
                Calculus_sf.frame.destroy()
                C_1.unbind("<Button>")
                C_1.place_forget()
                def Calculus_SFadd1():
                    global width4
                    width4 += 2#add
                    MainUI.place_configure(width=width4)
                    if width4 >= 200:
                        MathCUI.place_configure(width=200)
                        Algebra.place(anchor="n", x=100, y=0, width=160.0, height=30)
                        Calculus.place(anchor="n", x=100, y=30, width=160.0, height=30)
                        Data.place(anchor="n", x=100, y=60, width=160.0, height=30)
                        Geometry.place(anchor="n", x=100, y=90, width=160.0, height=30)
                        Physics.place(anchor="n", x=100, y=120, width=160.0, height=30)
                        Numbers.place(anchor="n", x=100, y=150, width=160.0, height=30)
                        text1.place(anchor=NE, relx=1, relheight=1, relwidth=1, width=-202)
                        return 0
                    w.after(1, Calculus_SFadd1)
                Calculus_SFadd1()
            def Calculus_SFplus1():
                global width4
                width4 -= 2#add
                MainUI.place_configure(width=width4)
                if width4 <= 40:
                    C_1.place(anchor=S, x=20, rely=1, y=-10)
                    C_1.bind("<Button-1>", c_1button_1_2)
                    Calculus_sf.place(anchor=NW, relheight=1 ,relwidth=1, width=-40, x=40)
                    return 0
                w.after(1, Calculus_SFplus1)
            Calculus_SFplus1()
            
            Calculus_sf = ScrollbarFrame(w, bg=style["CanvasW"]["Background"])
            Calculus_sf.binding(style["CanvasW"]["Background"]) 
            Calculus_sf.do()
            
            Label(Calculus_sf.frame2, text="Calculus:", fg=style["ChooseUI"], bg=style["CanvasW"]["Background"], font=("黑体", 20)).pack(anchor=NW, side='top')
            Label(Calculus_sf.frame2, text="极限:", bg=style["CanvasW"]["Background"], fg=style["CanvasW"]["TextFore"], font=("黑体", 13)).pack(anchor=NW, padx=20)
            padx = 50
            b1 = LButton(Calculus_sf.frame2, text="极限简介", bg=style["CanvasW"]["Background"])
            b1.pack(anchor=NW, padx=padx)
            b1.binding(sf=Calculus_sf, func=c_1button_1_2, type=0, file=".include/calculus/calculus2.frame2")
            b2 = LButton(Calculus_sf.frame2, text="极限和无限", bg=style["CanvasW"]["Background"])
            b2.pack(anchor=NW, padx=padx)
            b2.binding(sf=Calculus_sf, func=c_1button_1_2)

        Algebra = lButton(MathCUI, text=" 代数 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Algebra.binding(math2)
        Calculus = lButton(MathCUI, text=" 微积分 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Calculus.binding(math3)
        Data = lButton(MathCUI, text=" 数据 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Data.binding(useless)
        Geometry = lButton(MathCUI, text=" 几何 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Geometry.binding(useless)
        Physics = lButton(MathCUI, text=" 物理 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Physics.binding(useless)
        Numbers = lButton(MathCUI, text=" 数字 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Numbers.binding(useless)
        
        Back = lButton(MathCUI, text=lang["10002"], compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
        Back.binding(back)
        
    def always_2025(event):
        D.acter()
        D.unbind("<Button-1>")
        Today = Toplevel()
        Today['bg'] = style["ChooseUI"]
        Today.geometry("490x250")
        Today.resizable(False, False)
        Today.iconbitmap(".image/icon/image64.ico")
        Today.wm_iconbitmap(".image/icon/image64.ico")
        tText1 = FrameRead(Today, bg=style["ChooseUI"], fg=style["TextFore2"], font=("黑体", 13))
        tText1.place(relheight=0.7, relwidth=0.7, anchor=CENTER, relx=0.5, rely=0.5)
        tText1.binding()
        text1 = """今年是不同的:

    |(20+25)²                 = 2025
    |(1+2+3+4+5+6+7+8+9)²     = 2025
    |1³+2³+3³+4³+5³+6³+7³+8³+9³ = 2025
        """
        tText1.insert(INSERT, text1)
        tText1.tag_add("tag_body_1", 1.0, 1.19)
        tText1.tag_config("tag_body_1", font=("CENSCBK", 17, "bold"))
        def _():
            D.bind("<Button-1>", always_2025)
            Today.destroy()
        Today.wm_protocol("WM_DELETE_WINDOW", _)
    ChooseUI = Frame(w, bg=style["ChooseUI"])
    ChooseUI.place(relheight=1, height=-80, y=80, anchor=NW, width=width)
    A = lButton(ChooseUI, text=" 设置 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    A.binding(settings)
    A.place(anchor="n", x=100, y=0, width=160.0, height=30)
    B = lButton(ChooseUI, text=" 关于 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    B.binding(about)
    B.place(anchor="n", x=100, y=30, width=160.0, height=30)
    C = lButton(ChooseUI, text=lang["10004"], compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    C.binding(math1)
    C.place(anchor="n", x=100, y=60, width=160.0, height=30)
    D = lButton(ChooseUI, text=" 2025 ", compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    D.binding(always_2025)
    D.place(anchor="n", x=100, y=90, width=160.0, height=30)
    Z = lButton(ChooseUI, text=lang["10003"], compound="left", background=style["lButton"]["Before"]["TextBack"], foreground=style["lButton"]["Before"]["TextFore"])
    Z.binding(close)
    Z.place(anchor="s", x=100, rely=1, y=-10, width=160.0, height=30)
    def _():
        if Config.get("Startup", "Size") == "2":
            setconfig(f"WindowSize", f"{w.winfo_width()}x{w.winfo_height()}")
        w.destroy()
    w.wm_protocol("WM_DELETE_WINDOW", _)
    w.mainloop()
# 执行
if __name__ == "__main__":
    main()
