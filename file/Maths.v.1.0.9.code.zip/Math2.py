from tkinter import * 
import tkinter.ttk as ttk
import sv_ttk
from threading import Thread
from time import sleep
from PIL import Image, ImageTk
from math import *


pages = []
slc = eval(open(".style/default.sl", "r", encoding="utf-8").read())
version = open("version.set", "r", encoding="utf-8").read().split("\n")


class ScrollbarFrame(Canvas):
    def __init__(self, master=None, **kw):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.place(relheight=1, relx=1, x=5, anchor=NE)

        kw.update({'yscrollcommand': self.vbar.set})

        Canvas.__init__(self, self.frame, **kw)
        self.place(relheight=1, relwidth=1, width=-15)
        self.vbar['command'] = self.yview

        def myfunction(event):
            self.configure(scrollregion=self.bbox("all"), highlightthickness=0, relief=FLAT, bd=0)
        self.frame2 = ttk.Frame(self, relief=FLAT)
        self.__important__ = self.create_window((0,0), window=self.frame2, anchor=N, width=700)
        
        global wheel

        def wheel(event):
            if self.vbar.get() == (0.0, 1.0):
                pass
            else:
                self.yview_scroll(-1*(int(event.delta/120)), "units")

        self.frame2.bind("<MouseWheel>", wheel)
        self.bind("<MouseWheel>", wheel)
        self.frame2.bind("<Configure>", myfunction)

        text_meths = vars(Canvas).keys()
        methods = vars(Pack).keys() | vars(Grid).keys() | vars(Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

    def do(self, type=2):
        def loop():
            while 1:
                try:
                    if type == 1:
                        width = int(self.canvasx(self.winfo_width()/2))
                        self.coords(self.__important__, width, 0)
                    elif type == 2:
                        width = self.winfo_width()
                        self.itemconfig(self.__important__, width=width)
                    sleep(0.00001)
                except:
                    break
        self.th = Thread(target=loop, daemon=True)
        self.th.start()

    def read(self, filepath):
       file = open(file=filepath, mode="r", encoding="utf-8")
       exec(file.read())
       file.close()

    def color(self, color):
        self.frame2['background'] = color

class conputlib:
    def __init__(self, master,  c0:tuple, c1:tuple, step, wait_time=0, col="background", func=None):
        self.master= master
        self.N = -1
        self.c0 = c0
        self.c1 = c1
        self.RGB = self.R = self.G = self.B = self.color = None
        self.step = step

        def _func():
            self.N += 1
            self.RGB = (
                self.c0[0]+(self.c1[0]-self.c0[0]) * self.N / self.step,
                self.c0[1]+(self.c1[1]-self.c0[1]) * self.N / self.step,
                self.c0[2]+(self.c1[2]-self.c0[2]) * self.N / self.step
            )
            self.R = hex(int(self.RGB[0])).replace("0x", "")
            self.G = hex(int(self.RGB[1])).replace("0x", "")
            self.B = hex(int(self.RGB[2])).replace("0x", "")
            if len(self.R) == 1:
                self.R = "0" + self.R
            if len(self.G) == 1:
                self.G = "0" + self.G
            if len(self.B) == 1:
                self.B = "0" + self.B

            self.master[col] = f"#{self.R}{self.G}{self.B}"

            if self.N == self.step:
                if func != None:
                    return func()
                else:
                    return "break"
         
            w.after(10, _func)
        w.after(wait_time, _func)
    def output(self):
        return self.N

class loading:
    def __init__(self, master:Label, func="un", value=200):
        self.master = master
        self.sec    = 0
        self.value  = value
        self.master.place_configure(x=-int(self.value/2))
        self.func   = func

        def loop():
            for i in range(0, self.value):
                self.master.place_configure(width=i)
                if i >= 120:
                    self.sec += 0.0005
                    sleep(self.sec)
                sleep(0.01)
            if self.func == "un":
                return "break"
            else:
                self.func()
            

        self.th = Thread(target=loop, daemon=True)
        self.th.start()

class moveR:
    def __init__(self, master:Frame, x):
        self.master = master
        self.sec = 0
        self.x = x
        var = self.x-x*sin(89*pi/180)

        def fluent_change():
            while 1:
                var2 = self.x-x*sin(self.sec*pi/180)
                self.master.place(x=var2)
                if self.sec<89:
                    sleep(0.01)
                    self.sec += 1
                if var2 == var:
                    break
            return "break"
        
        self.th = Thread(target=fluent_change, daemon=True)
        self.th.start()

class moveL:
    def __init__(self, master:Frame, x):
        self.master = master
        self.sec = 0
        self.x = x
        var = self.x-(self.x-x*sin(89*pi/180))

        def fluent_change():
            while 1:
                var2 = self.x-(self.x-x*sin(self.sec*pi/180))
                self.master.place(x=var2)
                if self.sec<89:
                    sleep(0.01)
                    self.sec += 1
                if var2 == var:
                    break
            return "break"
        
        self.th = Thread(target=fluent_change, daemon=True)
        self.th.start()

class ChooseLabel:
    def __init__(self, master, text: tuple, func: tuple, y=0, frame_background="#ffffff", frame_anchor=NW, cBefore="#000000", cAfter="#f3f3f3", frame_width=200, cClick_bg="#5a5a5a", foreground="#000000", cClick_fg="#eaeaea", line_color="#005a9e", line_width=2):
        """
        初始化 ChooseLabel 类

        参数:
        master (Widget): 父容器
        text (tuple): 按钮文本的元组
        func (tuple): 按钮点击事件的元组
        y (int): Frame 的 y 坐标
        frame_background (str): Frame 的背景颜色
        frame_anchor (str): Frame 的锚点
        cBefore (str): 按钮默认背景颜色
        cAfter (str): 鼠标悬停时按钮的背景颜色
        frame_width (int): Frame 的宽度
        cClick_bg (str): 按钮点击时的背景颜色
        foreground (str): 按钮的前景颜色
        cClick_fg (str): 按钮点击时的前景颜色
        line_color (str): 线条的颜色
        line_width (int): 线条的宽度
        """
        self.frame = Frame(master=master, background=frame_background)
        self.frame.place(y=y, anchor=frame_anchor, width=frame_width, height=len(text) * 34)
        
        # 确保 func 是一个元组
        if not isinstance(func, tuple):
            func = (func,)
        
        # 如果 func 的长度不等于 text 的长度，填充 None
        if len(func) != len(text):
            func += (None,) * (len(text) - len(func))
        
        self.func = func

        self.buttons = []
        self.current_button = None  # 用于跟踪当前被按下的按钮
        for i in range(len(text)):
            button = ttk.Label(self.frame, text=f"   {text[i]} ", justify="left", font=("微软雅黑", 10), background=cBefore, foreground=foreground)
            button.place(anchor=NW, x=5, y=i * 34, width=190, height=30)
            button.bind("<Enter>", lambda event, btn=button: btn.config(background=cAfter, foreground=foreground))
            button.bind("<Leave>", lambda event, btn=button: btn.config(background=cBefore if btn != self.current_button else cClick_bg, foreground=foreground))
            button.bind("<Button-1>", lambda event, btn=button, idx=i: self.on_button_click(btn, idx, cClick_fg, cClick_bg, foreground, cBefore))
            self.buttons.append(button)
        
        self.line = ttk.Label(self.frame, background=line_color)
        self.line.place(height=15, width=line_width, anchor=E, y=15, x=6)

        # 默认点击第一个按钮
        if self.buttons:
            self.on_button_click(self.buttons[0], 0, cClick_fg, cClick_bg, foreground, cBefore)

    def on_button_click(self, button, index, cClick_fg, cClick_bg, foreground, cBefore):
        """
        按钮点击事件处理

        参数:
        button (Widget): 被点击的按钮
        index (int): 按钮的索引
        cClick_fg (str): 按钮点击时的前景颜色
        cClick_bg (str): 按钮点击时的背景颜色
        foreground (str): 按钮的前景颜色
        cBefore (str): 按钮默认背景颜色
        """
        if self.current_button:
            self.current_button.config(background=cBefore, foreground=foreground)
        button.config(background=cClick_bg, foreground=cClick_fg)
        self.current_button = button
        self.animate_line(index * 34 + 15)
        
        if callable(self.func[index]):
            self.func[index]()

    def animate_line(self, target_y):
        """
        动画移动线条到目标位置

        参数:
        target_y (int): 目标 y 坐标
        """
        def move():
            current_y = self.line.winfo_y()
            step = (target_y - current_y) / 10  # 缓冲效果

            while abs(target_y - current_y) > 1:
                current_y += step
                self.line.place(y=current_y)
                sleep(0.01)

            self.line.place(y=target_y)
            return "break"

        self.th = Thread(target=move, daemon=True).start()
    

def main():
    global w

    w = Tk()
    # 窗口配置
    w.title(version[1])
    w.geometry("768x475")
    w.iconbitmap(".image/icon/images64.ico")
    w.wm_iconbitmap(".image/icon/images64.ico")
    w.wm_minsize(width=768, height=475)

    background = Frame(w, background="#ffffff")
    background.place(anchor=NW, relheight=1, relwidth=1)
    loading1 = Label(background, background="#1c7ba7")
    loading1.place(anchor="w", relx=0.5, rely=0.5, y=44, x=-50, height=4, width=0)
    _img = Label(background, text="M", background="#1c7ba7", foreground="#ffffff", font=("Century", 30))
    _img.place(anchor=CENTER, relx=0.5, rely=0.5, width=64, height=64, y=-20)
    
    def main2():
        style_frame = ttk.Style()
        style_frame.configure("TFrame", background="#ffffff")
        
        UIa = Frame(w, bg="#ff00ff")
        UIa.place(relheight=1, relwidth=1)
        
        choose = Frame(UIa, background=slc["background"]["choose"])
        choose.place(relheight=1, width=200, x=-200)
        moveR(choose, x=-200)
        Label(choose, background="#198cc1", font=("Century", 24), text="M", foreground="#ffffff").place(x=5, y=15, width=45, height=45)
        
        
        UIb = Frame(w, bg="red")
        UIb.place(relheight=1, relwidth=1, relx=1)  
        def setting():
            moveL(UIb, x=-768)
            moveL(UIa, x=-768)
            Button(UIb, text="返回", command=lambda: (moveR(UIb, x=-768), moveR(UIa, x=-768))).place(x=5, y=75, width=190, height=30)
        
        
        ChooseLabel(choose, ("关于", "设置", "数学", "其他"), func=(None, setting), y=75, frame_background=slc["background"]["choose"],
                     line_color="#ffffff", cBefore=slc["background"]["choose"], cAfter="#196f96",
                       cClick_bg="#166286", cClick_fg="#cccccc", foreground="#ffffff")      

        

    main2()

    """def d():
        background.destroy()
        return main2()
    def e():
        _img.destroy()
        loading1.destroy()
        conputlib(background, (28,123,167), (255,255, 255),50 , wait_time=500, func=d)
    def b():
        conputlib(_img, (255, 255, 255), (28,123,167), 50, wait_time=1000, col="foreground")
        conputlib(loading1, (255, 255, 255), (28,123,167), 50, wait_time=1000, func=e)

    def c():
        conputlib(background, (255, 255, 255), (28,123,167), 50, wait_time=1000)
        conputlib(loading1, (28,123,167), (255, 255, 255), 50, wait_time=1000, func=b)
        
    loading(loading1, func=c)"""


    sv_ttk.set_theme("light")

    w.mainloop()


if __name__ == "__main__":
    main()
